package ru.multienchant.anvil;

import org.junit.jupiter.api.Test;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.enchant.EnchantTarget;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Ванильные правила объединения уровней на наковальне. */
class MergeLogicTest {

    private final EnchantRegistry registry = new EnchantRegistry(List.of(
            CustomEnchant.builder("drill").maxLevel(3).anvilWeight(4)
                    .target(EnchantTarget.PICKAXE).chance(1, 33).build(),
            CustomEnchant.builder("magnet").maxLevel(1).anvilWeight(2)
                    .target(EnchantTarget.PICKAXE).build()));

    @Test
    void samelevelsCombine() {
        var r = MergeLogic.merge(Map.of("drill", 1), Map.of("drill", 1), registry, false);
        assertEquals(2, r.enchants().get("drill"));
    }

    @Test
    void level2Plus2Gives3() {
        var r = MergeLogic.merge(Map.of("drill", 2), Map.of("drill", 2), registry, false);
        assertEquals(3, r.enchants().get("drill"));
    }

    @Test
    void maxPlusMaxStaysMax() {
        var r = MergeLogic.merge(Map.of("drill", 3), Map.of("drill", 3), registry, false);
        assertEquals(3, r.enchants().get("drill"));
    }

    @Test
    void differentLevelsTakeMax() {
        var r = MergeLogic.merge(Map.of("drill", 1), Map.of("drill", 3), registry, false);
        assertEquals(3, r.enchants().get("drill"));
    }

    @Test
    void transferFromRightOnly() {
        var r = MergeLogic.merge(Map.of(), Map.of("magnet", 1), registry, false);
        assertEquals(1, r.enchants().get("magnet"));
    }

    @Test
    void overMaxLevelIsClamped() {
        var r = MergeLogic.merge(Map.of(), Map.of("drill", 99), registry, false);
        assertEquals(3, r.enchants().get("drill"));
    }

    @Test
    void unknownEnchantIsIgnored() {
        var r = MergeLogic.merge(Map.of(), Map.of("unknown_enchant", 2), registry, false);
        assertFalse(r.enchants().containsKey("unknown_enchant"));
        assertEquals(0, r.costWeight());
    }

    @Test
    void bookWeightIsHalved() {
        var item = MergeLogic.merge(Map.of(), Map.of("drill", 2), registry, false);
        var book = MergeLogic.merge(Map.of(), Map.of("drill", 2), registry, true);
        assertEquals(4 * 2, item.costWeight());
        assertEquals(2 * 2, book.costWeight());
    }

    @Test
    void leftEnchantsArePreserved() {
        var r = MergeLogic.merge(Map.of("drill", 2), Map.of("magnet", 1), registry, false);
        assertEquals(2, r.enchants().get("drill"));
        assertTrue(r.enchants().containsKey("magnet"));
    }
}
