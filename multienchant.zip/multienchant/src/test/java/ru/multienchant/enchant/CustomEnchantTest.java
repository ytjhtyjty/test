package ru.multienchant.enchant;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CustomEnchantTest {

    private final CustomEnchant drill = CustomEnchant.builder("drill")
            .maxLevel(3).anvilWeight(4)
            .target(EnchantTarget.PICKAXE).target(EnchantTarget.SHOVEL)
            .chance(1, 33).chance(2, 66).chance(3, 100)
            .build();

    @Test
    void clampLevelBounds() {
        assertEquals(1, drill.clampLevel(0));
        assertEquals(1, drill.clampLevel(-5));
        assertEquals(2, drill.clampLevel(2));
        assertEquals(3, drill.clampLevel(99));
    }

    @Test
    void levelValidation() {
        assertFalse(drill.isValidLevel(0));
        assertTrue(drill.isValidLevel(1));
        assertTrue(drill.isValidLevel(3));
        assertFalse(drill.isValidLevel(4));
    }

    @Test
    void chancePerLevel() {
        assertEquals(33.0, drill.chanceForLevel(1));
        assertEquals(100.0, drill.chanceForLevel(3));
        assertEquals(0.0, drill.chanceForLevel(4)); // незаданный уровень
    }

    @Test
    void appliesToTargets() {
        assertTrue(drill.appliesTo(Material.DIAMOND_PICKAXE));
        assertTrue(drill.appliesTo(Material.NETHERITE_SHOVEL));
        assertFalse(drill.appliesTo(Material.DIAMOND_AXE));
        assertFalse(drill.appliesTo(Material.STONE));
    }

    @Test
    void builderRejectsInvalidMaxLevel() {
        assertThrows(IllegalArgumentException.class, () ->
                CustomEnchant.builder("bad").maxLevel(0).target(EnchantTarget.PICKAXE).build());
        assertThrows(IllegalArgumentException.class, () ->
                CustomEnchant.builder("bad").maxLevel(4).target(EnchantTarget.PICKAXE).build());
    }

    @Test
    void builderRejectsMissingTargets() {
        assertThrows(IllegalArgumentException.class, () ->
                CustomEnchant.builder("bad").maxLevel(1).build());
    }

    @Test
    void registryRejectsDuplicateIds() {
        assertThrows(IllegalArgumentException.class, () -> new EnchantRegistry(List.of(
                CustomEnchant.builder("dup").maxLevel(1).target(EnchantTarget.PICKAXE).build(),
                CustomEnchant.builder("dup").maxLevel(1).target(EnchantTarget.PICKAXE).build())));
    }
}
