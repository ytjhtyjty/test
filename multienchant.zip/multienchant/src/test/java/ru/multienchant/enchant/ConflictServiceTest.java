package ru.multienchant.enchant;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConflictServiceTest {

    private final EnchantRegistry registry = new EnchantRegistry(List.of(
            CustomEnchant.builder("alpha").maxLevel(1)
                    .target(EnchantTarget.PICKAXE).conflict("beta").build(),
            CustomEnchant.builder("beta").maxLevel(1)
                    .target(EnchantTarget.PICKAXE).build(),
            CustomEnchant.builder("gamma").maxLevel(1)
                    .target(EnchantTarget.PICKAXE)
                    .conflict("minecraft:silk_touch").build()));

    private final ConflictService service = new ConflictService(registry);

    @Test
    void directionalConflictWorksBothWays() {
        // alpha объявляет конфликт с beta — работает в обе стороны
        assertTrue(service.hasConflict("alpha", Set.of("beta")));
        assertTrue(service.hasConflict("beta", Set.of("alpha")));
    }

    @Test
    void noConflictBetweenIndependent() {
        assertFalse(service.hasConflict("beta", Set.of("gamma")));
    }

    @Test
    void selfIsNotAConflict() {
        assertFalse(service.hasConflict("alpha", Set.of("alpha")));
    }

    @Test
    void vanillaConflictById() {
        assertTrue(service.hasConflict("gamma", Set.of("minecraft:silk_touch")));
        assertFalse(service.hasConflict("gamma", Set.of("minecraft:fortune")));
    }

    @Test
    void findConflictsReturnsAllMatches() {
        assertEquals(List.of("beta"), service.findConflicts("alpha", Set.of("beta", "gamma")));
    }

    @Test
    void emptyPresentSetNeverConflicts() {
        assertFalse(service.hasConflict("alpha", Set.of()));
    }
}
