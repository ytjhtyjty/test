package ru.multienchant.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RomanNumeralsTest {

    @Test
    void basicLevels() {
        assertEquals("I", RomanNumerals.toRoman(1));
        assertEquals("II", RomanNumerals.toRoman(2));
        assertEquals("III", RomanNumerals.toRoman(3));
    }

    @Test
    void higherValuesStillRoman() {
        assertEquals("IV", RomanNumerals.toRoman(4));
        assertEquals("X", RomanNumerals.toRoman(10));
    }

    @Test
    void nonPositiveFallsBackToArabic() {
        assertEquals("0", RomanNumerals.toRoman(0));
        assertEquals("-2", RomanNumerals.toRoman(-2));
    }
}
