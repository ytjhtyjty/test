package ru.multienchant.util;

import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ChanceUtilTest {

    private final Random random = new Random(42);

    @Test
    void zeroPercentNeverRolls() {
        for (int i = 0; i < 1000; i++) {
            assertFalse(ChanceUtil.roll(0.0, random));
        }
    }

    @Test
    void hundredPercentAlwaysRolls() {
        for (int i = 0; i < 1000; i++) {
            assertTrue(ChanceUtil.roll(100.0, random));
        }
    }

    @Test
    void negativeNeverRolls() {
        assertFalse(ChanceUtil.roll(-5.0, random));
    }

    @Test
    void chanceApproximatesPercent() {
        int hits = 0;
        int n = 100_000;
        for (int i = 0; i < n; i++) {
            if (ChanceUtil.roll(33.0, random)) hits++;
        }
        double ratio = hits * 100.0 / n;
        assertTrue(Math.abs(ratio - 33.0) < 1.5, "получено " + ratio + "%");
    }

    @Test
    void probabilisticRoundExactInteger() {
        assertEquals(3, ChanceUtil.probabilisticRound(3.0, random));
        assertEquals(0, ChanceUtil.probabilisticRound(0.0, random));
        assertEquals(0, ChanceUtil.probabilisticRound(-1.0, random));
    }

    @Test
    void probabilisticRoundAveragesToValue() {
        double sum = 0;
        int n = 100_000;
        for (int i = 0; i < n; i++) {
            sum += ChanceUtil.probabilisticRound(2.6, random);
        }
        double avg = sum / n;
        assertTrue(Math.abs(avg - 2.6) < 0.05, "среднее " + avg);
    }

    @Test
    void weightedLevelRespectsZeroWeights() {
        Map<Integer, Double> weights = Map.of(1, 90.0, 2, 10.0, 3, 0.0);
        for (int i = 0; i < 10_000; i++) {
            int level = ChanceUtil.pickWeightedLevel(weights, random);
            assertTrue(level == 1 || level == 2, "уровень III с нулевым весом выпал");
        }
    }

    @Test
    void emptyWeightsFallBackToOne() {
        assertEquals(1, ChanceUtil.pickWeightedLevel(Map.of(), random));
    }

    @Test
    void weightedLevelClampsToMax() {
        Map<Integer, Double> weights = Map.of(3, 100.0);
        // maxLevel = 1: даже при 100% весе третьего уровня результат клампится
        for (int i = 0; i < 100; i++) {
            assertEquals(1, ChanceUtil.weightedLevel(weights, 1));
        }
    }
}
