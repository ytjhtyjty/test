package ru.multienchant.mechanics;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Геометрия Бура: куб 3×3×3 без центрального блока. */
class DrillPlaneTest {

    @Test
    void cubeHas26Offsets() {
        assertEquals(26, DrillPlane.cubeOffsets().size());
    }

    @Test
    void cubeDoesNotContainCenter() {
        for (int[] o : DrillPlane.cubeOffsets()) {
            assertFalse(o[0] == 0 && o[1] == 0 && o[2] == 0,
                    "Центральный блок не должен входить в область Бура");
        }
    }

    @Test
    void allOffsetsAreUnique() {
        Set<String> seen = new HashSet<>();
        for (int[] o : DrillPlane.cubeOffsets()) {
            assertTrue(seen.add(o[0] + "," + o[1] + "," + o[2]),
                    "Смещения не должны повторяться");
        }
        assertEquals(26, seen.size());
    }

    @Test
    void allOffsetsWithinRadiusOne() {
        List<int[]> offsets = DrillPlane.cubeOffsets();
        for (int[] o : offsets) {
            assertTrue(Math.abs(o[0]) <= 1 && Math.abs(o[1]) <= 1 && Math.abs(o[2]) <= 1,
                    "Все смещения куба 3×3×3 должны быть в пределах [-1..1]");
        }
    }
}
