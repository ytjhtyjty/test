package ru.multienchant;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import ru.multienchant.acquisition.BookApplyListener;
import ru.multienchant.acquisition.BookFactory;
import ru.multienchant.acquisition.EnchantTableListener;
import ru.multienchant.acquisition.FishingListener;
import ru.multienchant.acquisition.LootTableListener;
import ru.multienchant.acquisition.VillagerTradeListener;
import ru.multienchant.command.MeCommand;
import ru.multienchant.config.ConfigManager;
import ru.multienchant.display.LoreService;
import ru.multienchant.durability.DurabilityService;
import ru.multienchant.enchant.ConflictService;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.fx.EffectsService;
import ru.multienchant.integration.IntegrationManager;
import ru.multienchant.locale.Messages;
import ru.multienchant.mechanics.DrillListener;
import ru.multienchant.mechanics.ExperienceListener;
import ru.multienchant.mechanics.LampListener;
import ru.multienchant.mechanics.LampService;
import ru.multienchant.mechanics.LavaWalkerListener;
import ru.multienchant.mechanics.LumberjackListener;
import ru.multienchant.pipeline.BlockBreakPipeline;
import ru.multienchant.pipeline.DropCalculator;
import ru.multienchant.pipeline.MagnetService;
import ru.multienchant.pipeline.ReentrancyGuard;
import ru.multienchant.pipeline.SmeltService;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.Stats;

/**
 * MultiEnchant — система кастомных чар для Purpur/Paper 1.21.x.
 *
 * Сборка зависимостей выполняется вручную через конструкторы (DI без фреймворка),
 * изменяемых синглтонов нет. Порядок инициализации:
 *   конфиги -> реестр чар -> сервисы -> слушатели -> команды -> интеграции.
 */
public final class MultiEnchantPlugin extends JavaPlugin {

    private LampService lampService;
    private SmeltService smeltService;
    private ConfigManager configManager;

    @Override
    public void onEnable() {
        // --- Конфигурация и локализация ---
        saveDefaultConfig();
        saveResourceIfAbsent("enchants.yml");
        saveResourceIfAbsent("loot.yml");
        saveResourceIfAbsent("messages.yml");
        saveResourceIfAbsent("integrations.yml");
        saveResourceIfAbsent("filter-catalogs.yml");

        configManager = new ConfigManager(this);
        ConfigManager.ReloadResult loaded = configManager.reload();
        if (!loaded.success()) {
            getLogger().severe("Ошибка загрузки конфигурации: " + loaded.error());
            getLogger().severe("Плагин отключается. Исправьте конфигурацию и перезапустите.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Messages и реестр чар собираются ConfigManager'ом при загрузке YAML
        Messages messages = configManager.messages();

        // --- Ядро ---
        EnchantRegistry registry = configManager.registry();
        ConflictService conflicts = new ConflictService(registry);
        PdcStorage storage = new PdcStorage(registry, getLogger());
        LoreService lore = new LoreService(storage, messages);
        Stats stats = new Stats();

        // --- Интеграции (WorldGuard/PlaceholderAPI подключаются только при наличии) ---
        IntegrationManager integrations = new IntegrationManager(configManager::snapshot, getLogger());
        integrations.detect();

        // --- Конвейер разрушения ---
        ReentrancyGuard guard = new ReentrancyGuard();
        smeltService = new SmeltService();
        smeltService.buildRecipeCache(); // кеш Material -> результат плавки из рецептов сервера
        DropCalculator dropCalculator = new DropCalculator();
        MagnetService magnetService = new MagnetService();
        DurabilityService durabilityService = new DurabilityService();
        EffectsService effectsService = new EffectsService(configManager::snapshot);

        // --- Фильтр добычи ---
        ru.multienchant.filter.FilterStorage filterStorage =
                new ru.multienchant.filter.FilterStorage(storage);
        ru.multienchant.filter.FilterService filterService =
                new ru.multienchant.filter.FilterService();
        ru.multienchant.filter.FilterMenuManager filterMenu =
                new ru.multienchant.filter.FilterMenuManager(configManager,
                        filterStorage, messages);

        BlockBreakPipeline pipeline = new BlockBreakPipeline(
                configManager, dropCalculator, smeltService, magnetService,
                durabilityService, effectsService, integrations, guard, stats,
                filterService, filterStorage);

        // --- Светильник ---
        lampService = new LampService(this, configManager, storage);
        lampService.start();

        // --- Получение чар ---
        BookFactory bookFactory = new BookFactory(registry, storage, lore);

        // --- Регистрация слушателей ---
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new DrillListener(configManager, storage, pipeline, guard), this);
        pm.registerEvents(new LumberjackListener(configManager, storage, pipeline, guard), this);
        pm.registerEvents(new LampListener(this, lampService), this);
        pm.registerEvents(new LavaWalkerListener(configManager, storage, integrations,
                effectsService), this);
        pm.registerEvents(new ExperienceListener(this, configManager, storage), this);
        // Наложение книг: клик книгой по предмету в инвентаре (замена наковальни)
        pm.registerEvents(new BookApplyListener(storage, registry, conflicts, lore, messages), this);
        pm.registerEvents(new EnchantTableListener(this, configManager, registry, conflicts,
                storage, lore), this);
        pm.registerEvents(new LootTableListener(configManager, bookFactory), this);
        pm.registerEvents(new FishingListener(configManager, bookFactory), this);
        pm.registerEvents(new VillagerTradeListener(this, configManager, bookFactory), this);
        // Фильтр: GUI, дроп блоков без Бура/Лесоруба, дроп мобов, копия при переносе книгой
        pm.registerEvents(filterMenu, this);
        pm.registerEvents(new ru.multienchant.filter.FilterBlockDropListener(
                configManager, storage, filterStorage, filterService), this);
        pm.registerEvents(new ru.multienchant.filter.FilterMobDeathListener(
                configManager, storage, filterStorage, filterService), this);

        // --- Команды ---
        MeCommand meCommand = new MeCommand(configManager, registry, conflicts, storage,
                lore, bookFactory, messages, stats, filterStorage, filterMenu);
        PluginCommand command = getCommand("multienchant");
        if (command != null) {
            command.setExecutor(meCommand);
            command.setTabCompleter(meCommand);
        }

        // --- PlaceholderAPI ---
        integrations.registerPlaceholders(storage, registry,
                getPluginMeta().getVersion());

        getLogger().info("MultiEnchant включён: " + registry.all().size() + " чар, "
                + "автоплавка знает " + smeltService.cacheSize() + " рецептов.");
    }

    @Override
    public void onDisable() {
        if (lampService != null) {
            lampService.stop(); // снимаем наши эффекты со всех игроков
        }
        getLogger().info("MultiEnchant отключён.");
    }

    private void saveResourceIfAbsent(String name) {
        if (!new java.io.File(getDataFolder(), name).exists()) {
            saveResource(name, false);
        }
    }
}
