package ru.multienchant.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.display.LoreService;
import ru.multienchant.enchant.ConflictService;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.acquisition.BookFactory;
import ru.multienchant.locale.Messages;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.RomanNumerals;
import ru.multienchant.util.Stats;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Команда /multienchant (алиас /me): роутер подкоманд.
 *
 * help | list | info <id> | give <player> <id> <level> | apply <id> <level> |
 * remove <id> | reload | inspect
 *
 * Права: multienchant.command.<подкоманда> (см. plugin.yml).
 */
public final class MeCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of(
            "help", "list", "info", "give", "apply", "remove", "reload", "inspect", "filter");

    private final ConfigManager config;
    private final EnchantRegistry registry;
    private final ConflictService conflicts;
    private final PdcStorage storage;
    private final LoreService lore;
    private final BookFactory bookFactory;
    private final Messages messages;
    private final Stats stats;
    private final ru.multienchant.filter.FilterStorage filterStorage;
    private final ru.multienchant.filter.FilterMenuManager filterMenu;

    public MeCommand(ConfigManager config, EnchantRegistry registry, ConflictService conflicts,
                     PdcStorage storage, LoreService lore, BookFactory bookFactory,
                     Messages messages, Stats stats,
                     ru.multienchant.filter.FilterStorage filterStorage,
                     ru.multienchant.filter.FilterMenuManager filterMenu) {
        this.config = config;
        this.registry = registry;
        this.conflicts = conflicts;
        this.storage = storage;
        this.lore = lore;
        this.bookFactory = bookFactory;
        this.messages = messages;
        this.stats = stats;
        this.filterStorage = filterStorage;
        this.filterMenu = filterMenu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);

        if (!sender.hasPermission("multienchant.command." + sub)) {
            sender.sendMessage(messages.get("no-permission"));
            return true;
        }

        switch (sub) {
            case "help" -> sendHelp(sender);
            case "list" -> list(sender);
            case "info" -> info(sender, args);
            case "give" -> give(sender, args);
            case "apply" -> apply(sender, args);
            case "remove" -> remove(sender, args);
            case "reload" -> reload(sender);
            case "inspect" -> inspect(sender);
            case "filter" -> filter(sender, args);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        messages.getList("help").forEach(sender::sendMessage);
    }

    private void list(CommandSender sender) {
        sender.sendMessage(messages.get("list-header"));
        for (CustomEnchant e : registry.all()) {
            sender.sendMessage(messages.format("list-entry",
                    Map.of("id", e.id(),
                           "name", messages.enchantName(e.id()),
                           "max", RomanNumerals.toRoman(e.maxLevel()),
                           "enabled", e.enabled() ? "✔" : "✘")));
        }
    }

    private void info(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(messages.get("usage-info"));
            return;
        }
        var opt = registry.byId(args[1].toLowerCase(Locale.ROOT));
        if (opt.isEmpty()) {
            sender.sendMessage(messages.format("unknown-enchant", Map.of("id", args[1])));
            return;
        }
        CustomEnchant e = opt.get();
        sender.sendMessage(messages.format("info-header",
                Map.of("name", messages.enchantName(e.id()))));
        sender.sendMessage(messages.format("info-body", Map.of(
                "id", e.id(),
                "max", RomanNumerals.toRoman(e.maxLevel()),
                "targets", String.join(", ", e.targets().stream().map(Enum::name).toList()),
                "description", messages.enchantDescription(e.id()))));
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(messages.get("usage-give"));
            return;
        }
        Player target = sender.getServer().getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(messages.format("player-not-found", Map.of("player", args[1])));
            return;
        }
        var opt = registry.byId(args[2].toLowerCase(Locale.ROOT));
        if (opt.isEmpty()) {
            sender.sendMessage(messages.format("unknown-enchant", Map.of("id", args[2])));
            return;
        }
        int level = parseLevel(args[3], opt.get().maxLevel());
        if (level <= 0) {
            sender.sendMessage(messages.format("invalid-level",
                    Map.of("max", String.valueOf(opt.get().maxLevel()))));
            return;
        }
        ItemStack book = bookFactory.createBook(opt.get(), level);
        Map<Integer, ItemStack> overflow = target.getInventory().addItem(book);
        overflow.values().forEach(rest ->
                target.getWorld().dropItemNaturally(target.getLocation(), rest));
        sender.sendMessage(messages.format("give-success", Map.of(
                "player", target.getName(), "name", messages.enchantName(opt.get().id()),
                "level", RomanNumerals.toRoman(level))));
    }

    private void apply(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.get("players-only"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(messages.get("usage-apply"));
            return;
        }
        var opt = registry.byId(args[1].toLowerCase(Locale.ROOT));
        if (opt.isEmpty()) {
            sender.sendMessage(messages.format("unknown-enchant", Map.of("id", args[1])));
            return;
        }
        CustomEnchant e = opt.get();
        int level = parseLevel(args[2], e.maxLevel());
        if (level <= 0) {
            sender.sendMessage(messages.format("invalid-level",
                    Map.of("max", String.valueOf(e.maxLevel()))));
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            sender.sendMessage(messages.get("no-item-in-hand"));
            return;
        }

        boolean bypass = config.allowConflictBypass()
                && player.hasPermission("multienchant.bypass.conflicts");

        if (!bypass) {
            if (!EnchantTarget.matches(e.targets(), item.getType())) {
                sender.sendMessage(messages.format("wrong-item",
                        Map.of("name", messages.enchantName(e.id()))));
                return;
            }
            Map<String, Integer> current = storage.readEnchants(item);
            if (conflicts.hasConflict(e, current.keySet(), item)) {
                sender.sendMessage(messages.format("conflict",
                        Map.of("name", messages.enchantName(e.id()))));
                return;
            }
        }

        Map<String, Integer> current = storage.readEnchants(item);
        current.put(e.id(), level);
        storage.writeEnchants(item, current);
        lore.update(item, current);
        sender.sendMessage(messages.format("apply-success", Map.of(
                "name", messages.enchantName(e.id()), "level", RomanNumerals.toRoman(level))));
    }

    private void remove(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.get("players-only"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(messages.get("usage-remove"));
            return;
        }
        String id = args[1].toLowerCase(Locale.ROOT);
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            sender.sendMessage(messages.get("no-item-in-hand"));
            return;
        }
        Map<String, Integer> current = storage.readEnchants(item);
        if (current.remove(id) == null) {
            sender.sendMessage(messages.format("not-on-item", Map.of("id", id)));
            return;
        }
        storage.writeEnchants(item, current);
        lore.update(item, current);
        sender.sendMessage(messages.format("remove-success", Map.of("id", id)));
    }

    private void reload(CommandSender sender) {
        // Атомарная перезагрузка: при ошибке валидации остаётся предыдущая конфигурация
        ConfigManager.ReloadResult result = config.reload();
        if (result.success()) {
            sender.sendMessage(messages.get("reload-success"));
        } else {
            sender.sendMessage(messages.format("reload-failed", Map.of("error", result.error())));
        }
    }

    private void inspect(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.get("players-only"));
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            sender.sendMessage(messages.get("no-item-in-hand"));
            return;
        }
        sender.sendMessage(messages.get("inspect-header"));
        Map<String, Integer> raw = storage.readEnchantsRaw(item);
        if (raw.isEmpty()) {
            sender.sendMessage(messages.get("inspect-empty"));
        }
        for (Map.Entry<String, Integer> entry : raw.entrySet()) {
            boolean known = registry.byId(entry.getKey()).isPresent();
            boolean valid = known && entry.getValue() >= 1
                    && entry.getValue() <= registry.byId(entry.getKey()).get().maxLevel();
            sender.sendMessage(messages.format("inspect-entry", Map.of(
                    "id", entry.getKey(),
                    "level", String.valueOf(entry.getValue()),
                    "status", !known ? messages.raw("inspect-unknown")
                            : valid ? messages.raw("inspect-ok") : messages.raw("inspect-invalid"))));
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Long> stat : stats.summary().entrySet()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(stat.getKey()).append('=').append(stat.getValue());
        }
        sender.sendMessage(messages.format("inspect-stats",
                Map.of("stats", sb.length() == 0 ? "-" : sb.toString())));
    }

    /** /me filter [reset|inspect] — GUI фильтра добычи и админ-подкоманды. */
    private void filter(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.get("players-only"));
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            sender.sendMessage(messages.get("filter.no-item"));
            return;
        }
        if (!filterStorage.hasFilter(item)) {
            sender.sendMessage(messages.get("filter.not-enchanted"));
            return;
        }

        String action = args.length >= 2 ? args[1].toLowerCase(Locale.ROOT) : "";
        switch (action) {
            case "reset" -> {
                if (!player.hasPermission("multienchant.command.filter.reset")) {
                    sender.sendMessage(messages.get("no-permission"));
                    return;
                }
                filterStorage.reset(item);
                sender.sendMessage(messages.get("filter.reset-done"));
            }
            case "inspect" -> {
                if (!player.hasPermission("multienchant.command.filter.inspect")) {
                    sender.sendMessage(messages.get("no-permission"));
                    return;
                }
                filterInspect(player, item);
            }
            default -> filterMenu.open(player, item);
        }
    }

    private void filterInspect(Player player, ItemStack item) {
        var disabled = filterStorage.getDisabled(item);
        var id = filterStorage.peekItemId(item);
        boolean isSword = EnchantTarget.SWORD.matches(item.getType());
        StringBuilder list = new StringBuilder();
        for (var material : disabled) {
            if (list.length() > 0) list.append(", ");
            list.append(material.name());
        }
        player.sendMessage(messages.get("filter.inspect-header"));
        player.sendMessage(messages.format("filter.inspect-body", Map.of(
                "id", id == null ? "-" : id.toString(),
                "count", String.valueOf(disabled.size()),
                "materials", list.length() == 0 ? "-" : list.toString(),
                "version", String.valueOf(filterStorage.formatVersion(item)),
                "catalog", messages.raw(isSword ? "filter.catalog-mobs" : "filter.catalog-blocks"))));
    }

    private int parseLevel(String raw, int max) {
        try {
            int level = Integer.parseInt(raw);
            return (level >= 1 && level <= max) ? level : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (args.length == 1) {
            return filter(SUBCOMMANDS, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        List<String> ids = registry.all().stream().map(CustomEnchant::id).toList();
        switch (sub) {
            case "info", "apply", "remove" -> {
                if (args.length == 2) return filter(ids, args[1]);
                if (args.length == 3 && sub.equals("apply")) return List.of("1", "2", "3");
            }
            case "give" -> {
                if (args.length == 2) return null; // список игроков от сервера
                if (args.length == 3) return filter(ids, args[2]);
                if (args.length == 4) return List.of("1", "2", "3");
            }
            case "filter" -> {
                if (args.length == 2) return filter(List.of("reset", "inspect"), args[1]);
            }
            default -> { /* нет дополнений */ }
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) out.add(o);
        }
        return out;
    }
}
