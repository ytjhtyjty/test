package ru.multienchant.locale;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;

/**
 * Локализация из messages.yml (формат MiniMessage).
 * Плейсхолдеры вида {key} подставляются до десериализации.
 */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final ConfigurationSection root;
    private final String prefix;

    public Messages(ConfigurationSection root) {
        this.root = root;
        this.prefix = root.getString("prefix", "");
    }

    public String enchantName(String enchantId) {
        return root.getString("enchant-names." + enchantId, enchantId);
    }

    public String enchantDescription(String enchantId) {
        return root.getString("enchant-descriptions." + enchantId, "");
    }

    /** Компонент без префикса. Пары kv: ключ1, значение1, ключ2, значение2... */
    public Component get(String path, String... kv) {
        return MM.deserialize(raw(path, kv));
    }

    /** Компонент с подстановкой плейсхолдеров из Map (значения приводятся к строке). */
    public Component format(String path, java.util.Map<String, ?> placeholders) {
        String text = root.getString(path, "<red>[missing: " + path + "]</red>");
        for (java.util.Map.Entry<String, ?> entry : placeholders.entrySet()) {
            text = text.replace("{" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }
        return MM.deserialize(text);
    }

    /** Отправка с префиксом. */
    public void send(CommandSender sender, String path, String... kv) {
        sender.sendMessage(MM.deserialize(prefix + raw(path, kv)));
    }

    /** Отправка без префикса (для списков/заголовков). */
    public void sendPlain(CommandSender sender, String path, String... kv) {
        sender.sendMessage(get(path, kv));
    }

    public List<Component> getList(String path) {
        List<Component> result = new ArrayList<>();
        for (String line : root.getStringList(path)) {
            result.add(MM.deserialize(line));
        }
        return result;
    }

    /** Сырая строка с подстановкой плейсхолдеров (для tab completion и plain-текста). */
    public String raw(String path, String... kv) {
        String text = root.getString(path, "<red>[missing: " + path + "]</red>");
        for (int i = 0; i + 1 < kv.length; i += 2) {
            text = text.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return text;
    }
}
