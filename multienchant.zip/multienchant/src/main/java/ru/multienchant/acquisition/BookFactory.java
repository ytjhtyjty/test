package ru.multienchant.acquisition;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.display.LoreService;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.ChanceUtil;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Фабрика зачарованных книг с кастомными чарами.
 * Книга — обычный ENCHANTED_BOOK с PDC-данными в том же формате, что и предметы.
 */
public final class BookFactory {

    private final EnchantRegistry registry;
    private final PdcStorage storage;
    private final LoreService lore;

    public BookFactory(EnchantRegistry registry, PdcStorage storage, LoreService lore) {
        this.registry = registry;
        this.storage = storage;
        this.lore = lore;
    }

    /** Книга с конкретной чарой и уровнем. */
    public ItemStack createBook(CustomEnchant enchant, int level) {
        int clamped = Math.max(1, Math.min(level, enchant.maxLevel()));
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        Map<String, Integer> data = Map.of(enchant.id(), clamped);
        storage.writeEnchants(book, data);
        storage.markAsBook(book);
        lore.update(book, data);
        return book;
    }

    /** Случайная чара по весам из списка включённых. */
    public Optional<ItemStack> createRandomBook(Map<Integer, Double> levelWeights) {
        List<CustomEnchant> pool = registry.all().stream()
                .filter(CustomEnchant::enabled)
                .toList();
        if (pool.isEmpty()) return Optional.empty();

        CustomEnchant chosen = pool.get(ChanceUtil.randomIndex(pool.size()));
        int level = ChanceUtil.weightedLevel(levelWeights, chosen.maxLevel());
        return Optional.of(createBook(chosen, level));
    }
}
