package ru.multienchant.acquisition;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.display.LoreService;
import ru.multienchant.enchant.ConflictService;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.ChanceUtil;

import java.util.List;
import java.util.Map;

/**
 * Получение кастомных чар через стол зачарований.
 *
 * Шанс зависит от слота (кнопки): 1-й = 1%, 2-й = 3%, 3-й = 5% (настраивается).
 * Кастомная чара ДОБАВЛЯЕТСЯ к ванильному результату, не заменяя его.
 * Запись в предмет выполняется на 1 тик позже (после применения ванильных чар).
 */
public final class EnchantTableListener implements Listener {

    private final Plugin plugin;
    private final ConfigManager config;
    private final EnchantRegistry registry;
    private final ConflictService conflicts;
    private final PdcStorage storage;
    private final LoreService lore;

    public EnchantTableListener(Plugin plugin, ConfigManager config, EnchantRegistry registry,
                                ConflictService conflicts, PdcStorage storage, LoreService lore) {
        this.plugin = plugin;
        this.config = config;
        this.registry = registry;
        this.conflicts = conflicts;
        this.storage = storage;
        this.lore = lore;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchant(EnchantItemEvent event) {
        if (!config.acquisition().tableEnabled()) return;

        // Шанс по слоту: whichButton() = 0/1/2
        double chance = config.acquisition().tableSlotChance(event.whichButton());
        if (!ChanceUtil.roll(chance)) return;

        ItemStack item = event.getItem();
        Player player = event.getEnchanter();

        // Подходящие по типу предмета включённые чары без конфликтов
        List<CustomEnchant> candidates = registry.all().stream()
                .filter(CustomEnchant::enabled)
                .filter(e -> EnchantTarget.matches(e.targets(), item.getType()))
                .filter(e -> !conflicts.hasConflictWithVanilla(e, event.getEnchantsToAdd().keySet()))
                .toList();
        if (candidates.isEmpty()) return;

        CustomEnchant chosen = candidates.get(ChanceUtil.randomIndex(candidates.size()));
        int level = ChanceUtil.weightedLevel(
                config.acquisition().tableLevelWeights(), chosen.maxLevel());

        // Применяем на следующий тик — ванильные чары уже записаны в предмет
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            ItemStack target = event.getInventory().getItem(0);
            if (target == null) return;
            Map<String, Integer> current = storage.readEnchants(target);
            if (current.containsKey(chosen.id())) return;
            current.put(chosen.id(), level);
            storage.writeEnchants(target, current);
            lore.update(target, current);
            player.updateInventory();
        });
    }
}
