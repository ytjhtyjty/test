package ru.multienchant.acquisition;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.anvil.MergeLogic;
import ru.multienchant.display.LoreService;
import ru.multienchant.enchant.ConflictService;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.locale.Messages;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.RomanNumerals;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Наложение кастомной книги на предмет прямо в инвентаре:
 * игрок берёт зачарованную книгу на курсор и кликает ЛКМ по предмету.
 *
 * Правила:
 *  - чара должна подходить предмету по типу (EnchantTarget);
 *  - конфликты с чарами предмета (кастомными и ванильными) блокируют перенос;
 *  - уровни объединяются ванильно (I+I=II, разные -> max) через MergeLogic;
 *  - книга расходуется, только если хотя бы одна чара была перенесена.
 */
public final class BookApplyListener implements Listener {

    private final PdcStorage storage;
    private final EnchantRegistry registry;
    private final ConflictService conflicts;
    private final LoreService lore;
    private final Messages messages;

    public BookApplyListener(PdcStorage storage, EnchantRegistry registry,
                             ConflictService conflicts, LoreService lore, Messages messages) {
        this.storage = storage;
        this.registry = registry;
        this.conflicts = conflicts;
        this.lore = lore;
        this.messages = messages;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (event.getClick() != ClickType.LEFT) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();

        // На курсоре — наша книга, под курсором — предмет (не книга и не воздух)
        if (cursor == null || cursor.getType() != Material.ENCHANTED_BOOK) return;
        if (target == null || target.getType().isAir()
                || target.getType() == Material.ENCHANTED_BOOK) return;

        Map<String, Integer> bookEnchants = storage.readEnchants(cursor);
        if (bookEnchants.isEmpty()) return; // обычная ванильная книга — не трогаем

        event.setCancelled(true); // предотвращаем ванильный swap предмета и книги

        Map<String, Integer> itemEnchants = storage.readEnchants(target);

        // Отбираем переносимые чары: подходят по типу и не конфликтуют
        Map<String, Integer> transferable = new LinkedHashMap<>();
        boolean wrongItem = false;
        boolean conflicted = false;
        for (Map.Entry<String, Integer> entry : bookEnchants.entrySet()) {
            CustomEnchant def = registry.byId(entry.getKey()).orElse(null);
            if (def == null) continue;
            if (!EnchantTarget.matches(def.targets(), target.getType())) {
                wrongItem = true;
                continue;
            }
            if (conflicts.hasConflict(def, itemEnchants.keySet(), target)) {
                conflicted = true;
                continue;
            }
            transferable.put(entry.getKey(), entry.getValue());
        }

        if (transferable.isEmpty()) {
            String firstId = bookEnchants.keySet().iterator().next();
            String name = messages.enchantName(firstId);
            if (conflicted) {
                player.sendMessage(messages.format("conflict", Map.of("name", name)));
            } else if (wrongItem) {
                player.sendMessage(messages.format("wrong-item", Map.of("name", name)));
            }
            return;
        }

        // Ванильное объединение уровней (I+I=II, разные -> max, кламп по max уровню)
        MergeLogic.MergeResult merged = MergeLogic.merge(itemEnchants, transferable, registry, true);

        storage.writeEnchants(target, merged.enchants());
        lore.update(target, merged.enchants());

        // Книга «Фильтр»: новый пустой список отключённых материалов (§14 ТЗ) —
        // только если чара появилась впервые (не перетираем существующие настройки)
        if (transferable.containsKey(ru.multienchant.enchant.EnchantIds.FILTER)
                && !itemEnchants.containsKey(ru.multienchant.enchant.EnchantIds.FILTER)) {
            new ru.multienchant.filter.FilterStorage(storage).initEmpty(target);
        }

        // Книга расходуется (одна штука)
        int amount = cursor.getAmount();
        if (amount <= 1) {
            player.setItemOnCursor(null);
        } else {
            cursor.setAmount(amount - 1);
            player.setItemOnCursor(cursor);
        }

        // Сообщение по каждой перенесённой чаре — с русским названием
        for (Map.Entry<String, Integer> entry : transferable.entrySet()) {
            int resultLevel = merged.enchants().getOrDefault(entry.getKey(), entry.getValue());
            player.sendMessage(messages.format("book-applied", Map.of(
                    "name", messages.enchantName(entry.getKey()),
                    "level", RomanNumerals.toRoman(resultLevel))));
        }
        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.6f, 1.2f);
    }
}
