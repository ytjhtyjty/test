package ru.multienchant.acquisition;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.util.ChanceUtil;

/**
 * Кастомные книги в луте структур.
 *
 * LootGenerateEvent срабатывает ОДИН раз при генерации лута сундука —
 * повторные открытия того же сундука событие не вызывают, дубли исключены.
 * Список таблиц лута и шанс настраиваются в loot.yml.
 */
public final class LootTableListener implements Listener {

    private final ConfigManager config;
    private final BookFactory bookFactory;

    public LootTableListener(ConfigManager config, BookFactory bookFactory) {
        this.config = config;
        this.bookFactory = bookFactory;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLootGenerate(LootGenerateEvent event) {
        if (!config.loot().enabled()) return;

        String tableKey = event.getLootTable().getKey().toString();
        if (!config.loot().tables().contains(tableKey)) return;

        if (!ChanceUtil.roll(config.loot().chance())) return;

        bookFactory.createRandomBook(config.loot().levelWeights())
                .ifPresent(book -> event.getLoot().add(book));
    }
}
