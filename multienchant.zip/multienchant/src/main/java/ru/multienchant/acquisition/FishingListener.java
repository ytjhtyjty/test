package ru.multienchant.acquisition;

import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.util.ChanceUtil;

/**
 * Кастомные книги при рыбалке (категория "сокровище").
 *
 * Ванильная логика сокровищ учитывается так:
 *  - сокровища ловятся только в открытой воде (FishHook#isInOpenWater);
 *  - "Морская удача" (LUCK_OF_THE_SEA) повышает шанс модификатором из конфига.
 * При срабатывании выловленный предмет заменяется книгой (не дополняется),
 * чтобы не увеличивать общий доход от рыбалки.
 */
public final class FishingListener implements Listener {

    private final ConfigManager config;
    private final BookFactory bookFactory;

    public FishingListener(ConfigManager config, BookFactory bookFactory) {
        this.config = config;
        this.bookFactory = bookFactory;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (!config.acquisition().fishingEnabled()) return;
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        if (!(event.getCaught() instanceof Item caughtItem)) return;

        // Сокровища — только в открытой воде (ванильное правило)
        if (!event.getHook().isInOpenWater()) return;

        double chance = config.acquisition().fishingChance();

        // Морская удача: множитель шанса за уровень
        ItemStack rod = event.getPlayer().getInventory().getItemInMainHand();
        int luck = rod.getEnchantmentLevel(Enchantment.LUCK_OF_THE_SEA);
        if (luck > 0) {
            chance *= 1.0 + luck * config.acquisition().fishingLuckMultiplier();
        }

        if (!ChanceUtil.roll(chance)) return;

        bookFactory.createRandomBook(config.acquisition().fishingLevelWeights())
                .ifPresent(caughtItem::setItemStack);
    }
}
