package ru.multienchant.acquisition;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.util.ChanceUtil;

import java.util.List;

/**
 * Кастомные книги в сделках библиотекарей уровня "Мастер".
 *
 * Защита от дублей: на PDC жителя ставится маркер multienchant:trade=1 после
 * первой сгенерированной кастомной сделки — один житель может предложить
 * не более одной кастомной книги.
 *
 * Цена: 40-64 изумруда + обычная книга (настраивается). Использований: 3,
 * восстановление сделки по умолчанию отключено (maxUses фиксирован).
 */
public final class VillagerTradeListener implements Listener {

    private final NamespacedKey tradeKey;
    private final ConfigManager config;
    private final BookFactory bookFactory;

    public VillagerTradeListener(Plugin plugin, ConfigManager config, BookFactory bookFactory) {
        this.tradeKey = new NamespacedKey(plugin, "trade");
        this.config = config;
        this.bookFactory = bookFactory;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAcquireTrade(VillagerAcquireTradeEvent event) {
        if (!config.acquisition().villagerEnabled()) return;
        if (!(event.getEntity() instanceof Villager villager)) return;
        if (villager.getProfession() != Villager.Profession.LIBRARIAN) return;

        // Кастомная сделка появляется только при достижении уровня "Мастер"
        if (villager.getVillagerLevel() < 5) return;

        // Анти-дубль: один житель — максимум одна кастомная сделка
        Integer marked = villager.getPersistentDataContainer()
                .get(tradeKey, PersistentDataType.INTEGER);
        if (marked != null) return;

        if (!ChanceUtil.roll(config.acquisition().villagerChance())) return;

        var bookOpt = bookFactory.createRandomBook(config.acquisition().villagerLevelWeights());
        if (bookOpt.isEmpty()) return;

        int emeralds = config.acquisition().villagerPriceMin()
                + ChanceUtil.randomIndex(config.acquisition().villagerPriceMax()
                        - config.acquisition().villagerPriceMin() + 1);

        MerchantRecipe recipe = new MerchantRecipe(bookOpt.get(),
                config.acquisition().villagerMaxUses());
        recipe.setIngredients(List.of(
                new ItemStack(Material.EMERALD, emeralds),
                new ItemStack(Material.BOOK)));
        recipe.setExperienceReward(true);
        recipe.setVillagerExperience(5);

        event.setRecipe(recipe);
        villager.getPersistentDataContainer().set(tradeKey, PersistentDataType.INTEGER, 1);
    }
}
