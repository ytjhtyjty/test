package ru.multienchant.mechanics;

import org.bukkit.GameMode;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.pipeline.BlockBreakPipeline;
import ru.multienchant.pipeline.ReentrancyGuard;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.ChanceUtil;

import java.util.List;
import java.util.Map;

/**
 * Чара "Лесоруб": срубание всего дерева при разрушении нижнего бревна.
 * BFS по связным брёвнам с жёстким лимитом блоков (по умолчанию 128).
 * Шанс срабатывания: I=33%, II=66%, III=100%. Один бросок на срабатывание.
 */
public final class LumberjackListener implements Listener {

    private final ConfigManager config;
    private final PdcStorage storage;
    private final BlockBreakPipeline pipeline;
    private final ReentrancyGuard guard;

    public LumberjackListener(ConfigManager config, PdcStorage storage,
                              BlockBreakPipeline pipeline, ReentrancyGuard guard) {
        this.config = config;
        this.storage = storage;
        this.pipeline = pipeline;
        this.guard = guard;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();

        if (guard.isInside(player.getUniqueId())) return;
        if (!config.lumberjack().enabled()) return;
        if (player.getGameMode() == GameMode.CREATIVE && !config.lumberjack().creativeEnabled()) return;
        if (config.lumberjack().sneakDisables() && player.isSneaking()) return;

        // Только брёвна запускают механику
        if (!Tag.LOGS.isTagged(event.getBlock().getType())) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        Map<String, Integer> enchants = storage.readEnchants(tool);
        int level = enchants.getOrDefault(EnchantIds.LUMBERJACK, 0);
        if (level <= 0) return;

        double chance = config.lumberjack().chance(level);
        if (!ChanceUtil.roll(chance)) return;

        List<Block> tree = TreeScanner.scan(
                event.getBlock(),
                config.lumberjack().maxBlocks(),
                config.lumberjack().includeLeaves(),
                config.lumberjack().maxLeaves());
        tree.removeIf(b -> !pipeline.isBreakable(b, player, tool)
                && !Tag.LEAVES.isTagged(b.getType())); // листья добываются любым инструментом

        pipeline.processTrigger(event, tree, enchants, "lumberjack");
    }
}
