package ru.multienchant.mechanics;

import org.bukkit.Tag;
import org.bukkit.block.Block;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Лесоруб: BFS-обход связного дерева от сломанного бревна.
 * Соседство 3×3×3 (диагонали учитываются — стволы деревьев бывают изогнутыми).
 * Жёсткие лимиты блоков защищают от «съедания» построек из брёвен.
 */
public final class TreeScanner {

    private TreeScanner() {
    }

    /**
     * @param origin      сломанное бревно (не включается в результат)
     * @param logLimit    максимум брёвен
     * @param withLeaves  включать ли листья
     * @param leavesLimit максимум листьев
     * @return брёвна (в порядке BFS), затем листья
     */
    public static List<Block> scan(Block origin, int logLimit, boolean withLeaves, int leavesLimit) {
        List<Block> logs = new ArrayList<>();
        List<Block> leaves = new ArrayList<>();
        Set<Block> visited = new HashSet<>();
        Deque<Block> queue = new ArrayDeque<>();
        visited.add(origin);
        queue.add(origin);

        while (!queue.isEmpty() && logs.size() < logLimit) {
            Block current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        Block next = current.getRelative(dx, dy, dz);
                        if (!visited.add(next)) {
                            continue;
                        }
                        if (Tag.LOGS.isTagged(next.getType())) {
                            if (logs.size() < logLimit) {
                                logs.add(next);
                                queue.add(next);
                            }
                        } else if (withLeaves && Tag.LEAVES.isTagged(next.getType())
                                && leaves.size() < leavesLimit) {
                            leaves.add(next);
                            queue.add(next); // листья соединяют части кроны
                        }
                    }
                }
            }
        }
        List<Block> result = new ArrayList<>(logs);
        result.addAll(leaves);
        return result;
    }
}
