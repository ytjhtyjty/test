package ru.multienchant.mechanics;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Levelled;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.EntityBlockFormEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.fx.EffectsService;
import ru.multienchant.integration.IntegrationManager;
import ru.multienchant.storage.PdcStorage;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Чара "Лавоход": превращение источников лавы под ногами в обсидиан.
 * Радиус: I=1, II=2, III=3.
 *
 * Производительность:
 *  - обработка только при смене блочных координат игрока;
 *  - лимит блоков за срабатывание и per-second лимит на игрока;
 *  - только источники лавы (level=0) без лавы сверху (текущая лава — опционально).
 *
 * Совместимость: превращение оформляется cancellable-событием
 * EntityBlockFormEvent (как ванильный Frost Walker) — другие плагины могут отменить.
 */
public final class LavaWalkerListener implements Listener {

    private final ConfigManager config;
    private final PdcStorage storage;
    private final IntegrationManager integrations;
    private final EffectsService effects;

    /** Rate limit: окно 1 секунда на игрока. */
    private static final class RateWindow {
        long windowStartMs;
        int converted;
    }

    private final Map<UUID, RateWindow> rateLimits = new ConcurrentHashMap<>();

    public LavaWalkerListener(ConfigManager config, PdcStorage storage,
                              IntegrationManager integrations, EffectsService effects) {
        this.config = config;
        this.storage = storage;
        this.integrations = integrations;
        this.effects = effects;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!config.lavaWalker().enabled()) return;

        // Только при смене блочных координат — дешёвая ранняя проверка
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack boots = player.getInventory().getBoots();
        if (boots == null) return;

        Map<String, Integer> enchants = storage.readEnchants(boots);
        int level = enchants.getOrDefault(EnchantIds.LAVA_WALKER, 0);
        if (level <= 0) return;

        // Rate limit на игрока
        RateWindow window = rateLimits.computeIfAbsent(player.getUniqueId(), k -> new RateWindow());
        long now = System.currentTimeMillis();
        synchronized (window) {
            if (now - window.windowStartMs >= 1000L) {
                window.windowStartMs = now;
                window.converted = 0;
            }
            if (window.converted >= config.lavaWalker().maxPerSecond()) return;
        }

        int radius = config.lavaWalker().radius(level);
        Block feet = event.getTo().getBlock();
        Block below = feet.getRelative(BlockFace.DOWN);

        int convertedThisTrigger = 0;
        int maxPerTrigger = config.lavaWalker().maxPerTrigger();
        boolean converted = false;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (convertedThisTrigger >= maxPerTrigger) break;
                // Круглая область как у ванильного Frost Walker
                if (dx * dx + dz * dz > radius * radius + 1) continue;

                Block target = below.getRelative(dx, 0, dz);
                if (!isConvertibleLava(target)) continue;
                if (!integrations.canBuild(player, target)) continue;

                // Cancellable-событие для совместимости с другими плагинами
                org.bukkit.block.BlockState replaced = target.getState();
                replaced.setType(Material.OBSIDIAN);
                EntityBlockFormEvent formEvent = new EntityBlockFormEvent(player, target, replaced);
                player.getServer().getPluginManager().callEvent(formEvent);
                if (formEvent.isCancelled()) continue;

                target.setType(Material.OBSIDIAN, true);
                convertedThisTrigger++;
                converted = true;

                synchronized (window) {
                    window.converted++;
                    if (window.converted >= config.lavaWalker().maxPerSecond()) {
                        dx = radius + 1; // выход из внешнего цикла
                        break;
                    }
                }
            }
        }

        if (converted) {
            effects.play("lava-walker", player.getLocation());
        }
    }

    /**
     * Только источники лавы (level=0); блоки с лавой сверху пропускаются,
     * чтобы не создавать "дыры" в лавовых озёрах. Текущая лава — опционально.
     */
    private boolean isConvertibleLava(Block block) {
        if (block.getType() != Material.LAVA) return false;
        if (block.getBlockData() instanceof Levelled levelled) {
            if (levelled.getLevel() != 0 && !config.lavaWalker().convertFlowing()) return false;
        }
        return block.getRelative(BlockFace.UP).getType() != Material.LAVA;
    }

    public void forget(UUID id) {
        rateLimits.remove(id);
    }
}
