package ru.multienchant.mechanics;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.ChanceUtil;

import java.util.Map;

/**
 * Чара "Опыт": увеличение выпадающего опыта с мобов на +15/30/50%.
 * (Бонус за руды применяется в BlockBreakPipeline.)
 *
 * Для стрелкового оружия (лук/арбалет) уровень чары записывается в PDC
 * снаряда в момент выстрела — бонус корректно применяется, даже если игрок
 * сменил предмет в руке к моменту смерти цели.
 *
 * Дробный бонус округляется вероятностно: +0.5 XP = 50% шанс +1 XP.
 */
public final class ExperienceListener implements Listener {

    private final NamespacedKey projectileKey;
    private final ConfigManager config;
    private final PdcStorage storage;

    public ExperienceListener(Plugin plugin, ConfigManager config, PdcStorage storage) {
        this.projectileKey = new NamespacedKey(plugin, "xp_weapon_level");
        this.config = config;
        this.storage = storage;
    }

    /** Выстрел из лука/арбалета: переносим уровень чары на снаряд. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (!(event.getProjectile() instanceof Projectile projectile)) return;

        ItemStack bow = event.getBow();
        if (bow == null) return;

        Map<String, Integer> enchants = storage.readEnchants(bow);
        int level = enchants.getOrDefault(EnchantIds.EXPERIENCE, 0);
        if (level <= 0) return;

        projectile.getPersistentDataContainer().set(projectileKey, PersistentDataType.INTEGER, level);
    }

    /** Смерть моба: применяем бонус к ванильному опыту. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        if (!config.experience().enabled()) return;

        int vanillaXp = event.getDroppedExp();
        if (vanillaXp <= 0) return; // нет ванильного опыта — нет бонуса

        int level = resolveLevel(event);
        if (level <= 0) return;

        double bonus = config.experience().mobBonusPercent(level) / 100.0;
        int extra = ChanceUtil.probabilisticRound(vanillaXp * bonus);
        event.setDroppedExp(vanillaXp + extra);
    }

    /**
     * Определение уровня чары:
     *  - убийство снарядом -> уровень из PDC снаряда (не из текущего предмета в руке!);
     *  - убийство в ближнем бою -> уровень с предмета в руке убийцы.
     */
    private int resolveLevel(EntityDeathEvent event) {
        var damageEvent = event.getEntity().getLastDamageCause();
        if (damageEvent instanceof org.bukkit.event.entity.EntityDamageByEntityEvent byEntity) {
            if (byEntity.getDamager() instanceof Projectile projectile) {
                Integer stored = projectile.getPersistentDataContainer()
                        .get(projectileKey, PersistentDataType.INTEGER);
                return stored != null ? stored : 0;
            }
        }

        Player killer = event.getEntity().getKiller();
        if (killer == null) return 0;

        ItemStack weapon = killer.getInventory().getItemInMainHand();
        Map<String, Integer> enchants = storage.readEnchants(weapon);
        return enchants.getOrDefault(EnchantIds.EXPERIENCE, 0);
    }

    /** Очистка PDC снаряда после попадания (стрела могла воткнуться и лежать). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onProjectileHit(ProjectileHitEvent event) {
        // Если попали в сущность — данные ещё нужны для EntityDeathEvent (тот же тик),
        // очищаем только при попадании в блок.
        if (event.getHitEntity() == null && event.getEntity() instanceof AbstractArrow arrow) {
            arrow.getPersistentDataContainer().remove(projectileKey);
        }
    }
}
