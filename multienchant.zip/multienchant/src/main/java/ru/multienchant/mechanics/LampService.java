package ru.multienchant.mechanics;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.storage.PdcStorage;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Чара "Светильник": постоянное ночное зрение при ношении шлема с чарой.
 *
 * Модель: событийная (пересчёт при изменении экипировки/мира/жизни) +
 * редкий периодический таск (по умолчанию раз в 5 секунд) ТОЛЬКО для игроков
 * из отслеживаемого набора — поддерживает эффект и страхует от рассинхронизации.
 *
 * Эффект выдаётся с запасом длительности (по умолчанию 15 с при периоде 5 с),
 * поэтому мерцания в HUD нет. Чужой эффект ночного зрения (зелья, другие
 * плагины) не перезаписывается, если он сильнее или дольше нашего.
 */
public final class LampService {

    private final Plugin plugin;
    private final ConfigManager config;
    private final PdcStorage storage;

    /** Игроки, у которых сейчас активен наш эффект. */
    private final Set<UUID> active = ConcurrentHashMap.newKeySet();
    private BukkitTask task;

    public LampService(Plugin plugin, ConfigManager config, PdcStorage storage) {
        this.plugin = plugin;
        this.config = config;
        this.storage = storage;
    }

    public void start() {
        stop();
        long period = config.lamp().updatePeriodTicks();
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, period, period);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (UUID id : active) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) removeOurEffect(p);
        }
        active.clear();
    }

    /** Периодическое поддержание эффекта только у отслеживаемых игроков. */
    private void tick() {
        for (UUID id : active) {
            Player p = plugin.getServer().getPlayer(id);
            if (p == null || !p.isOnline()) {
                active.remove(id);
                continue;
            }
            if (hasLampHelmet(p)) {
                applyEffect(p);
            } else {
                active.remove(id);
                removeOurEffect(p);
            }
        }
    }

    /** Полный пересчёт состояния игрока (вызывается слушателем при событиях). */
    public void refresh(Player player) {
        if (!config.lamp().enabled()) return;
        if (hasLampHelmet(player)) {
            active.add(player.getUniqueId());
            applyEffect(player);
        } else if (active.remove(player.getUniqueId())) {
            removeOurEffect(player);
        }
    }

    public void forget(UUID id) {
        active.remove(id);
    }

    private boolean hasLampHelmet(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null) return false;
        Map<String, Integer> enchants = storage.readEnchants(helmet);
        return enchants.getOrDefault(EnchantIds.LAMP, 0) > 0;
    }

    private void applyEffect(Player player) {
        int duration = config.lamp().effectDurationTicks();
        PotionEffect existing = player.getPotionEffect(PotionEffectType.NIGHT_VISION);
        // Не перебиваем более сильный или более длинный чужой эффект
        if (existing != null && !isOurs(existing)
                && (existing.getAmplifier() > 0 || existing.getDuration() > duration)) {
            return;
        }
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.NIGHT_VISION, duration, 0,
                true /* ambient */, false /* particles */, true /* icon */));
    }

    private void removeOurEffect(Player player) {
        PotionEffect existing = player.getPotionEffect(PotionEffectType.NIGHT_VISION);
        if (existing != null && isOurs(existing)) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
    }

    /**
     * Наш эффект маркируется точной сигнатурой: amp=0, ambient=true, particles=false,
     * длительность не превышает выдаваемую нами.
     */
    private boolean isOurs(PotionEffect effect) {
        return effect.getAmplifier() == 0
                && effect.isAmbient()
                && !effect.hasParticles()
                && effect.getDuration() <= config.lamp().effectDurationTicks();
    }
}
