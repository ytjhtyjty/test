package ru.multienchant.mechanics;

import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.pipeline.BlockBreakPipeline;
import ru.multienchant.pipeline.ReentrancyGuard;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.ChanceUtil;

import java.util.List;
import java.util.Map;

/**
 * Чара "Бур": разрушение области 3×3×3 (куб) вокруг сломанного блока.
 * Шанс срабатывания: I=33%, II=66%, III=100% (настраивается в enchants.yml).
 * Один бросок шанса на срабатывание (на всё событие).
 */
public final class DrillListener implements Listener {

    private final ConfigManager config;
    private final PdcStorage storage;
    private final BlockBreakPipeline pipeline;
    private final ReentrancyGuard guard;

    public DrillListener(ConfigManager config, PdcStorage storage,
                         BlockBreakPipeline pipeline, ReentrancyGuard guard) {
        this.config = config;
        this.storage = storage;
        this.pipeline = pipeline;
        this.guard = guard;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();

        // Внутренние события конвейера не должны запускать Бур повторно
        if (guard.isInside(player.getUniqueId())) return;
        if (!config.drill().enabled()) return;

        // Creative: массовое разрушение по умолчанию выключено
        if (player.getGameMode() == GameMode.CREATIVE && !config.drill().creativeEnabled()) return;

        // Shift (приседание) временно отключает механику
        if (config.drill().sneakDisables() && player.isSneaking()) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        Map<String, Integer> enchants = storage.readEnchants(tool);
        int level = enchants.getOrDefault(EnchantIds.DRILL, 0);
        if (level <= 0) return;

        // Один бросок шанса на всё срабатывание
        double chance = config.drill().chance(level);
        if (!ChanceUtil.roll(chance)) return;

        // Куб 3×3×3 вокруг сломанного блока (26 дополнительных блоков)
        List<Block> area = DrillPlane.compute(event.getBlock(), player);
        if (config.drill().sameTypeOnly()) {
            area.removeIf(b -> b.getType() != event.getBlock().getType());
        }
        area.removeIf(b -> !pipeline.isBreakable(b, player, tool));

        pipeline.processTrigger(event, area, enchants, "drill");
    }
}
