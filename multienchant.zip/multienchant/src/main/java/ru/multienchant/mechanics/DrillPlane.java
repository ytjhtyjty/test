package ru.multienchant.mechanics;

import java.util.ArrayList;
import java.util.List;

/**
 * Геометрия Бура: область 3×3×3 (куб) вокруг разрушенного блока.
 * 26 смещений — все блоки куба, кроме центрального (он уже разрушен
 * самим событием). Чистая логика без Bukkit-мира — покрыта unit-тестами.
 */
public final class DrillPlane {

    private DrillPlane() {
    }

    /** Блоки куба 3×3×3 вокруг центрального (без него самого) — 26 штук. */
    public static List<org.bukkit.block.Block> compute(org.bukkit.block.Block center,
                                                       org.bukkit.entity.Player player) {
        List<org.bukkit.block.Block> blocks = new ArrayList<>(26);
        for (int[] o : cubeOffsets()) {
            blocks.add(center.getRelative(o[0], o[1], o[2]));
        }
        return blocks;
    }

    /** 26 смещений {dx, dy, dz} куба 3×3×3 без центра. */
    public static List<int[]> cubeOffsets() {
        List<int[]> offsets = new ArrayList<>(26);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx != 0 || dy != 0 || dz != 0) {
                        offsets.add(new int[]{dx, dy, dz});
                    }
                }
            }
        }
        return offsets;
    }
}
