package ru.multienchant.enchant;

import org.bukkit.Material;

/** Категории предметов, на которые можно накладывать кастомные чары. */
public enum EnchantTarget {
    PICKAXE,
    SHOVEL,
    AXE,
    HOE,
    HELMET,
    BOOTS,
    SWORD,
    BOW,
    CROSSBOW,
    TRIDENT;

    /** Подходит ли материал хотя бы одной из целей набора. */
    public static boolean matches(java.util.Set<EnchantTarget> targets, Material material) {
        for (EnchantTarget target : targets) {
            if (target.matches(material)) {
                return true;
            }
        }
        return false;
    }

    public boolean matches(Material material) {
        String name = material.name();
        return switch (this) {
            case PICKAXE -> name.endsWith("_PICKAXE");
            case SHOVEL -> name.endsWith("_SHOVEL");
            case AXE -> name.endsWith("_AXE");
            case HOE -> name.endsWith("_HOE");
            case HELMET -> name.endsWith("_HELMET") || material == Material.TURTLE_HELMET;
            case BOOTS -> name.endsWith("_BOOTS");
            case SWORD -> name.endsWith("_SWORD");
            case BOW -> material == Material.BOW;
            case CROSSBOW -> material == Material.CROSSBOW;
            case TRIDENT -> material == Material.TRIDENT;
        };
    }
}
