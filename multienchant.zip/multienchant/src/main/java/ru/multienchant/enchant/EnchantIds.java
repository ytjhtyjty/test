package ru.multienchant.enchant;

/** Стабильные id встроенных чар (хранятся в PDC — менять нельзя). */
public final class EnchantIds {

    public static final String DRILL = "drill";
    public static final String AUTO_SMELT = "auto_smelt";
    public static final String MAGNET = "magnet";
    public static final String LAMP = "lamp";
    public static final String LUMBERJACK = "lumberjack";
    public static final String LAVA_WALKER = "lava_walker";
    public static final String EXPERIENCE = "experience";
    public static final String FILTER = "filter";

    private EnchantIds() {
    }
}
