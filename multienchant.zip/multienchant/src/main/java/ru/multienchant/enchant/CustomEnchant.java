package ru.multienchant.enchant;

import org.bukkit.Material;

import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Определение кастомной чары. Неизменяемо; создаётся из enchants.yml.
 * Не содержит логики Bukkit-событий — только данные и простые вычисления.
 */
public final class CustomEnchant {

    private final String id;
    private final int maxLevel;
    private final int anvilWeight;
    private final Set<EnchantTarget> targets;
    private final Set<String> conflicts;
    private final Map<Integer, Double> chancePerLevel;
    private final Map<Integer, Double> bonusPerLevel;
    private final Map<Integer, Integer> radiusPerLevel;
    private final Map<String, String> stringParams;
    private final Map<String, Integer> intParams;
    private final Map<String, Boolean> boolParams;

    private CustomEnchant(Builder b) {
        this.id = b.id;
        this.maxLevel = b.maxLevel;
        this.anvilWeight = b.anvilWeight;
        this.targets = Collections.unmodifiableSet(EnumSet.copyOf(b.targets));
        this.conflicts = Collections.unmodifiableSet(new LinkedHashSet<>(b.conflicts));
        this.chancePerLevel = Collections.unmodifiableMap(new LinkedHashMap<>(b.chancePerLevel));
        this.bonusPerLevel = Collections.unmodifiableMap(new LinkedHashMap<>(b.bonusPerLevel));
        this.radiusPerLevel = Collections.unmodifiableMap(new LinkedHashMap<>(b.radiusPerLevel));
        this.stringParams = Collections.unmodifiableMap(new LinkedHashMap<>(b.stringParams));
        this.intParams = Collections.unmodifiableMap(new LinkedHashMap<>(b.intParams));
        this.boolParams = Collections.unmodifiableMap(new LinkedHashMap<>(b.boolParams));
    }

    public String id() {
        return id;
    }

    public int maxLevel() {
        return maxLevel;
    }

    public int anvilWeight() {
        return anvilWeight;
    }

    public Set<EnchantTarget> targets() {
        return targets;
    }

    public Set<String> conflicts() {
        return conflicts;
    }

    /** Включена ли чара (параметр enabled в enchants.yml, по умолчанию true). */
    public boolean enabled() {
        return boolParam("enabled", true);
    }

    /** Отображаемое имя (из messages.yml, записывается при сборке реестра). */
    public String displayName() {
        return stringParam("display-name", id);
    }

    /** Описание чары (из messages.yml, записывается при сборке реестра). */
    public String description() {
        return stringParam("description", "");
    }

    public boolean appliesTo(Material material) {
        for (EnchantTarget target : targets) {
            if (target.matches(material)) {
                return true;
            }
        }
        return false;
    }

    /** Уровень, приведённый к допустимому диапазону [1..maxLevel]. */
    public int clampLevel(int level) {
        return Math.max(1, Math.min(maxLevel, level));
    }

    public boolean isValidLevel(int level) {
        return level >= 1 && level <= maxLevel;
    }

    /** Шанс срабатывания для уровня, % (0, если не задан). */
    public double chanceForLevel(int level) {
        return chancePerLevel.getOrDefault(level, 0.0);
    }

    /** Бонус (например, к опыту) для уровня, %. */
    public double bonusForLevel(int level) {
        return bonusPerLevel.getOrDefault(level, 0.0);
    }

    /** Радиус действия для уровня (0, если не задан). */
    public int radiusForLevel(int level) {
        return radiusPerLevel.getOrDefault(level, 0);
    }

    public String stringParam(String key, String def) {
        return stringParams.getOrDefault(key, def);
    }

    public int intParam(String key, int def) {
        return intParams.getOrDefault(key, def);
    }

    public boolean boolParam(String key, boolean def) {
        return boolParams.getOrDefault(key, def);
    }

    public static Builder builder(String id) {
        return new Builder(id);
    }

    public static final class Builder {
        private final String id;
        private int maxLevel = 1;
        private int anvilWeight = 2;
        private Set<EnchantTarget> targets = EnumSet.noneOf(EnchantTarget.class);
        private Set<String> conflicts = new LinkedHashSet<>();
        private Map<Integer, Double> chancePerLevel = new LinkedHashMap<>();
        private Map<Integer, Double> bonusPerLevel = new LinkedHashMap<>();
        private Map<Integer, Integer> radiusPerLevel = new LinkedHashMap<>();
        private Map<String, String> stringParams = new LinkedHashMap<>();
        private Map<String, Integer> intParams = new LinkedHashMap<>();
        private Map<String, Boolean> boolParams = new LinkedHashMap<>();

        private Builder(String id) {
            this.id = id;
        }

        public Builder maxLevel(int v) {
            this.maxLevel = v;
            return this;
        }

        public Builder anvilWeight(int v) {
            this.anvilWeight = v;
            return this;
        }

        public Builder target(EnchantTarget t) {
            this.targets.add(t);
            return this;
        }

        public Builder conflict(String id) {
            this.conflicts.add(id);
            return this;
        }

        public Builder chance(int level, double percent) {
            this.chancePerLevel.put(level, percent);
            return this;
        }

        public Builder bonus(int level, double percent) {
            this.bonusPerLevel.put(level, percent);
            return this;
        }

        public Builder radius(int level, int radius) {
            this.radiusPerLevel.put(level, radius);
            return this;
        }

        public Builder stringParam(String key, String value) {
            this.stringParams.put(key, value);
            return this;
        }

        public Builder intParam(String key, int value) {
            this.intParams.put(key, value);
            return this;
        }

        public Builder boolParam(String key, boolean value) {
            this.boolParams.put(key, value);
            return this;
        }

        public CustomEnchant build() {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("id чары не может быть пустым");
            }
            if (maxLevel < 1 || maxLevel > 3) {
                throw new IllegalArgumentException("max-level чары '" + id + "' должен быть 1..3");
            }
            if (targets.isEmpty()) {
                throw new IllegalArgumentException("у чары '" + id + "' не задано ни одной цели (targets)");
            }
            return new CustomEnchant(this);
        }
    }
}
