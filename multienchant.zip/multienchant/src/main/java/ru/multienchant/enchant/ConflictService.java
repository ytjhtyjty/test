package ru.multienchant.enchant;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Проверка конфликтов чар. Чистая логика без Bukkit — покрыта unit-тестами.
 * Конфликт двунаправленный: достаточно объявления с любой стороны.
 * Ванильные чары указываются с префиксом "minecraft:" (напр. "minecraft:silk_touch").
 */
public final class ConflictService {

    private final EnchantRegistry registry;

    public ConflictService(EnchantRegistry registry) {
        this.registry = registry;
    }

    /**
     * Возвращает список id уже присутствующих чар, конфликтующих с новой.
     *
     * @param newEnchantId id накладываемой кастомной чары
     * @param presentIds   id всех чар на предмете: кастомные ("drill")
     *                     и ванильные ("minecraft:silk_touch")
     */
    public List<String> findConflicts(String newEnchantId, Set<String> presentIds) {
        List<String> result = new ArrayList<>();
        CustomEnchant newEnchant = registry.byId(newEnchantId).orElse(null);
        for (String presentId : presentIds) {
            if (presentId.equals(newEnchantId)) {
                continue;
            }
            boolean conflict = false;
            if (newEnchant != null && newEnchant.conflicts().contains(presentId)) {
                conflict = true;
            }
            CustomEnchant present = registry.byId(presentId).orElse(null);
            if (present != null && present.conflicts().contains(newEnchantId)) {
                conflict = true;
            }
            if (conflict) {
                result.add(presentId);
            }
        }
        return result;
    }

    public boolean hasConflict(String newEnchantId, Set<String> presentIds) {
        return !findConflicts(newEnchantId, presentIds).isEmpty();
    }

    /**
     * Конфликт новой чары с кастомными чарами предмета И его ванильными чарами.
     * Ванильные id получаются из ItemStack как "minecraft:silk_touch" и т.п.
     */
    public boolean hasConflict(CustomEnchant newEnchant, Set<String> presentCustomIds,
                               org.bukkit.inventory.ItemStack item) {
        Set<String> all = new java.util.LinkedHashSet<>(presentCustomIds);
        if (item != null) {
            for (org.bukkit.enchantments.Enchantment vanilla : item.getEnchantments().keySet()) {
                all.add(vanilla.getKey().toString());
            }
        }
        return hasConflict(newEnchant.id(), all);
    }

    /** Конфликт новой чары с набором ванильных чар (например, из EnchantItemEvent). */
    public boolean hasConflictWithVanilla(CustomEnchant newEnchant,
                                          Set<org.bukkit.enchantments.Enchantment> vanillaEnchants) {
        Set<String> ids = new java.util.LinkedHashSet<>();
        for (org.bukkit.enchantments.Enchantment vanilla : vanillaEnchants) {
            ids.add(vanilla.getKey().toString());
        }
        return hasConflict(newEnchant.id(), ids);
    }
}
