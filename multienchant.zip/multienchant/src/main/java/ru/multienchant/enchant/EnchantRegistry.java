package ru.multienchant.enchant;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Реестр кастомных чар по стабильным id. Неизменяем после создания. */
public final class EnchantRegistry {

    private final Map<String, CustomEnchant> byId;

    public EnchantRegistry(Collection<CustomEnchant> enchants) {
        Map<String, CustomEnchant> map = new LinkedHashMap<>();
        for (CustomEnchant enchant : enchants) {
            if (map.put(enchant.id(), enchant) != null) {
                throw new IllegalArgumentException("Дублирующийся id чары: " + enchant.id());
            }
        }
        this.byId = Collections.unmodifiableMap(map);
    }

    public Optional<CustomEnchant> byId(String id) {
        return Optional.ofNullable(byId.get(id));
    }

    public boolean contains(String id) {
        return byId.containsKey(id);
    }

    public Collection<CustomEnchant> all() {
        return byId.values();
    }

    public Set<String> ids() {
        return byId.keySet();
    }

    public int size() {
        return byId.size();
    }
}
