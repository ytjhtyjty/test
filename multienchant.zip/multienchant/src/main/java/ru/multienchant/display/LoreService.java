package ru.multienchant.display;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.multienchant.locale.Messages;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.RomanNumerals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Ванильно-подобное отображение чар в lore (Adventure Components).
 * Управляемые строки всегда находятся в начале lore; их количество
 * хранится в PDC (multienchant:lore_lines), чтобы при обновлении
 * не затрагивать пользовательские строки lore.
 */
public final class LoreService {

    private final PdcStorage storage;
    private final Messages messages;

    public LoreService(PdcStorage storage, Messages messages) {
        this.storage = storage;
        this.messages = messages;
    }

    /** Обновление lore по переданному набору чар (набор уже записан в PDC). */
    public void update(ItemStack item, Map<String, Integer> enchants) {
        updateLore(item);
    }

    /** Полностью пересобирает управляемую часть lore по текущим чарам предмета. */
    public void updateLore(ItemStack item) {
        if (item == null || item.getItemMeta() == null) {
            return;
        }
        ItemMeta meta = item.getItemMeta();

        int managed = meta.getPersistentDataContainer()
                .getOrDefault(PdcStorage.LORE_LINES_KEY, PersistentDataType.INTEGER, 0);

        List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        // Убираем прежние управляемые строки (клампим на случай внешних изменений lore)
        int toRemove = Math.min(Math.max(managed, 0), lore.size());
        if (toRemove > 0) {
            lore.subList(0, toRemove).clear();
        }

        List<Component> lines = buildLines(storage.getEnchants(item));
        lore.addAll(0, lines);

        if (lore.isEmpty()) {
            meta.lore(null);
        } else {
            meta.lore(lore);
        }
        if (lines.isEmpty()) {
            meta.getPersistentDataContainer().remove(PdcStorage.LORE_LINES_KEY);
        } else {
            meta.getPersistentDataContainer()
                    .set(PdcStorage.LORE_LINES_KEY, PersistentDataType.INTEGER, lines.size());
        }
        item.setItemMeta(meta);
    }

    private List<Component> buildLines(Map<String, Integer> enchants) {
        List<Component> lines = new ArrayList<>(enchants.size());
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            lines.add(line(entry.getKey(), entry.getValue()));
        }
        return lines;
    }

    /** Строка lore в ванильном стиле: серый цвет, без курсива, римский уровень (кроме I у чар с max=1). */
    public Component line(String enchantId, int level) {
        String name = messages.enchantName(enchantId);
        String text = level <= 1 ? name : name + " " + RomanNumerals.toRoman(level);
        return Component.text(text, NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false);
    }
}
