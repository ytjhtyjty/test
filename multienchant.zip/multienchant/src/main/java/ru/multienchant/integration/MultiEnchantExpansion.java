package ru.multienchant.integration;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.storage.PdcStorage;
import ru.multienchant.util.RomanNumerals;

import java.util.Locale;
import java.util.Map;

/**
 * PlaceholderAPI expansion.
 *
 * Плейсхолдеры:
 *  %multienchant_hand_<id>%        - уровень чары на предмете в руке (0 если нет)
 *  %multienchant_hand_<id>_roman%  - римскими цифрами ("" если нет)
 *  %multienchant_helmet_<id>%      - уровень чары на шлеме
 *  %multienchant_boots_<id>%       - уровень чары на ботинках
 *  %multienchant_count_hand%       - количество кастомных чар на предмете в руке
 */
public final class MultiEnchantExpansion extends PlaceholderExpansion {

    private final PdcStorage storage;
    private final EnchantRegistry registry;
    private final String version;

    public MultiEnchantExpansion(PdcStorage storage, EnchantRegistry registry, String version) {
        this.storage = storage;
        this.registry = registry;
        this.version = version;
    }

    @Override public @NotNull String getIdentifier() { return "multienchant"; }
    @Override public @NotNull String getAuthor() { return "MultiEnchant"; }
    @Override public @NotNull String getVersion() { return version; }
    @Override public boolean persist() { return true; }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";
        String p = params.toLowerCase(Locale.ROOT);

        if (p.equals("count_hand")) {
            return String.valueOf(storage.readEnchants(
                    player.getInventory().getItemInMainHand()).size());
        }

        ItemStack item;
        String rest;
        if (p.startsWith("hand_")) {
            item = player.getInventory().getItemInMainHand();
            rest = p.substring("hand_".length());
        } else if (p.startsWith("helmet_")) {
            item = player.getInventory().getHelmet();
            rest = p.substring("helmet_".length());
        } else if (p.startsWith("boots_")) {
            item = player.getInventory().getBoots();
            rest = p.substring("boots_".length());
        } else {
            return null; // неизвестный плейсхолдер
        }
        if (item == null) return "0";

        boolean roman = rest.endsWith("_roman");
        String id = roman ? rest.substring(0, rest.length() - "_roman".length()) : rest;
        if (registry.byId(id).isEmpty()) return null;

        Map<String, Integer> enchants = storage.readEnchants(item);
        int level = enchants.getOrDefault(id, 0);
        if (roman) return level > 0 ? RomanNumerals.toRoman(level) : "";
        return String.valueOf(level);
    }
}
