package ru.multienchant.integration;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import ru.multienchant.config.ConfigManager;

import java.util.function.Supplier;
import java.util.logging.Logger;

/**
 * Менеджер опциональных интеграций. Плагин полностью работоспособен
 * без WorldGuard и PlaceholderAPI: при их отсутствии хуки не создаются.
 */
public final class IntegrationManager {

    private final Supplier<ConfigManager.Snapshot> config;
    private final Logger logger;
    private WorldGuardHook worldGuard;
    private boolean papiAvailable;

    public IntegrationManager(Supplier<ConfigManager.Snapshot> config, Logger logger) {
        this.config = config;
        this.logger = logger;
    }

    /** Детект установленных плагинов; вызывается в onEnable. */
    public void detect() {
        if (Bukkit.getPluginManager().getPlugin("WorldGuard") != null) {
            try {
                this.worldGuard = new WorldGuardHook();
                logger.info("[MultiEnchant] Интеграция WorldGuard активна.");
            } catch (Throwable t) {
                logger.warning("[MultiEnchant] Не удалось подключить WorldGuard: " + t.getMessage());
            }
        }
        this.papiAvailable = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
        if (papiAvailable) {
            logger.info("[MultiEnchant] Интеграция PlaceholderAPI доступна.");
        }
    }

    public boolean isPapiAvailable() {
        return papiAvailable && config.get().integrations().placeholderapi();
    }

    /** Регистрация PAPI-расширения (только если PlaceholderAPI установлен и включён в конфиге). */
    public void registerPlaceholders(ru.multienchant.storage.PdcStorage storage,
                                     ru.multienchant.enchant.EnchantRegistry registry,
                                     String pluginVersion) {
        if (!isPapiAvailable()) {
            return;
        }
        try {
            new MultiEnchantExpansion(storage, registry, pluginVersion).register();
            logger.info("[MultiEnchant] PAPI-расширение зарегистрировано (%multienchant_...%).");
        } catch (Throwable t) {
            logger.warning("[MultiEnchant] Не удалось зарегистрировать PAPI-расширение: " + t.getMessage());
        }
    }

    /** Может ли игрок разрушить блок (для конвейера Бура/Лесоруба). */
    public boolean canBreak(Player player, org.bukkit.block.Block block) {
        return canModify(player, block.getLocation());
    }

    /** Может ли игрок изменить блок (для Лавохода). */
    public boolean canBuild(Player player, org.bukkit.block.Block block) {
        return canModify(player, block.getLocation());
    }

    /**
     * Может ли игрок изменять блок в данной точке.
     * Без WorldGuard (или при выключенной интеграции) — всегда true.
     */
    public boolean canModify(Player player, Location location) {
        if (worldGuard == null || !config.get().integrations().worldguard()) {
            return true;
        }
        try {
            return worldGuard.canBuild(player, location);
        } catch (Throwable t) {
            // Никогда не роняем механику из-за сбоя интеграции — фейлимся безопасно (запрет)
            logger.warning("[MultiEnchant] Ошибка проверки WorldGuard: " + t.getMessage());
            return false;
        }
    }
}
