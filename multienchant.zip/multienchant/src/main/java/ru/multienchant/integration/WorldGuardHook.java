package ru.multienchant.integration;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Хук WorldGuard. Класс загружается ТОЛЬКО при наличии плагина WorldGuard
 * (проверка в IntegrationManager) — иначе NoClassDefFoundError невозможен.
 */
final class WorldGuardHook {

    /** Может ли игрок строить/ломать в данной точке с учётом регионов. */
    boolean canBuild(Player player, Location location) {
        RegionQuery query = WorldGuard.getInstance().getPlatform()
                .getRegionContainer().createQuery();
        return query.testBuild(BukkitAdapter.adapt(location),
                WorldGuardPlugin.inst().wrapPlayer(player));
    }
}
