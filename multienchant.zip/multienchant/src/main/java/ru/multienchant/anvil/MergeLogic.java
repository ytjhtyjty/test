package ru.multienchant.anvil;

import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Чистая логика объединения кастомных чар (без Bukkit-зависимостей — unit-тестируемо).
 *
 * Ванильные правила:
 *  - одинаковый уровень: level + 1 (не выше max);
 *  - разные уровни: максимальный из двух;
 *  - чара только справа: переносится как есть (кламп по max).
 */
public final class MergeLogic {

    private MergeLogic() {}

    /** Результат объединения: итоговые чары + суммарный вес для стоимости. */
    public record MergeResult(Map<String, Integer> enchants, int costWeight) {}

    /**
     * @param left      чары левого предмета (id -> уровень)
     * @param right     чары правого предмета/книги (id -> уровень)
     * @param registry  реестр для max-уровней и anvil-weight
     * @param rightIsBook вес книги делится на 2 (ванильное правило)
     */
    public static MergeResult merge(Map<String, Integer> left,
                                    Map<String, Integer> right,
                                    EnchantRegistry registry,
                                    boolean rightIsBook) {
        Map<String, Integer> result = new LinkedHashMap<>(left);
        int costWeight = 0;

        for (Map.Entry<String, Integer> entry : right.entrySet()) {
            String id = entry.getKey();
            CustomEnchant def = registry.byId(id).orElse(null);
            if (def == null) continue; // неизвестная чара — не переносим и не ломаем

            int max = def.maxLevel();
            int rightLevel = Math.min(entry.getValue(), max);
            int leftLevel = result.getOrDefault(id, 0);

            int target;
            if (leftLevel == 0) {
                target = rightLevel;                       // перенос
            } else if (leftLevel == rightLevel) {
                target = Math.min(leftLevel + 1, max);     // I+I=II, II+II=III, III+III=III
            } else {
                target = Math.max(leftLevel, rightLevel);  // разные уровни -> max
            }
            result.put(id, target);

            int weight = def.anvilWeight();
            if (rightIsBook) weight = Math.max(1, weight / 2);
            costWeight += weight * target;
        }
        return new MergeResult(result, costWeight);
    }
}
