package ru.multienchant.filter;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Наковальня и «Фильтр» (§14 ТЗ):
 *  - ваниль копирует meta (включая PDC) ЛЕВОГО предмета в результат — настройки
 *    фильтра левого предмета наследуются автоматически, правый игнорируется;
 *  - PDC других плагинов не изменяется (мы трогаем только свои filter_* ключи);
 *  - результату назначается НОВЫЙ уникальный ID, чтобы не существовало
 *    двух предметов с одним filter_id.
 */
public final class FilterAnvilListener implements Listener {

    private final FilterStorage filterStorage;

    public FilterAnvilListener(FilterStorage filterStorage) {
        this.filterStorage = filterStorage;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        ItemStack result = event.getResult();
        if (result == null || result.getType().isAir()) return;
        if (!filterStorage.hasFilter(result)) return;

        // Настройки уже унаследованы от левого предмета (копия meta) —
        // осталось исключить дубликат уникального ID
        filterStorage.regenerateItemId(result);
        event.setResult(result);
    }
}
