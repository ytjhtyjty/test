package ru.multienchant.filter;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Чистая логика чары «Фильтр»: удаление из списка дропа предметов,
 * материал которых отключён игроком.
 *
 * Правила:
 *  - сравнение выполняется ТОЛЬКО по Material — прочность, название,
 *    зачарования, lore и прочие метаданные игнорируются;
 *  - сферы опыта не затрагиваются (фильтр работает только с ItemStack);
 *  - дроп игроков и сторонний дроп обрабатываются вызывающими слушателями
 *    (сюда такие списки просто не попадают).
 */
public final class FilterService {

    /** Удаляет из списка (in-place) все стеки с отключённым материалом. */
    public void filterDrops(List<ItemStack> drops, Set<Material> disabled) {
        if (disabled.isEmpty() || drops.isEmpty()) {
            return;
        }
        drops.removeIf(stack -> stack != null && disabled.contains(stack.getType()));
    }

    /** true, если материал стека отключён. */
    public boolean isFiltered(ItemStack stack, Set<Material> disabled) {
        return stack != null && disabled.contains(stack.getType());
    }

    /** Безопасная копия набора (для передачи в конвейер). */
    public EnumSet<Material> copy(Set<Material> disabled) {
        return disabled.isEmpty() ? EnumSet.noneOf(Material.class) : EnumSet.copyOf(disabled);
    }
}
