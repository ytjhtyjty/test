package ru.multienchant.filter;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.storage.PdcStorage;

import java.util.Set;

/**
 * Фильтрация дропа при ОБЫЧНОМ разрушении блока (без Бура/Лесоруба —
 * их дроп идёт через BlockBreakPipeline, где фильтр применяется отдельно).
 *
 * Используется BlockDropItemEvent (NORMAL приоритет):
 *  - список содержит только ванильный дроп ЭТОГО разрушения — предметы
 *    на земле, инвентарь и дроп других игроков не затрагиваются;
 *  - итог уже учитывает Удачу и Шёлковое касание;
 *  - сторонние плагины, добавляющие дроп отдельными сущностями или на более
 *    позднем приоритете, не затрагиваются (при сомнении предмет сохраняется);
 *  - опыт события не изменяется; прочность и само разрушение не отменяются.
 */
public final class FilterBlockDropListener implements Listener {

    private final ConfigManager config;
    private final PdcStorage storage;
    private final FilterStorage filterStorage;
    private final FilterService filterService;

    public FilterBlockDropListener(ConfigManager config, PdcStorage storage,
                                   FilterStorage filterStorage, FilterService filterService) {
        this.config = config;
        this.storage = storage;
        this.filterStorage = filterStorage;
        this.filterService = filterService;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockDrop(BlockDropItemEvent event) {
        if (!config.filter().enabled()) return;

        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();

        // Фильтр действует только если блок сломан ИМЕННО этим инструментом
        if (tool.getType().isAir()) return;
        if (!storage.has(tool, EnchantIds.FILTER)) return;

        Set<Material> disabled = filterStorage.getDisabled(tool);
        if (disabled.isEmpty()) return;

        // Удаляем только сущности ванильного дропа этого события
        event.getItems().removeIf(item ->
                filterService.isFiltered(item.getItemStack(), disabled));
    }
}
