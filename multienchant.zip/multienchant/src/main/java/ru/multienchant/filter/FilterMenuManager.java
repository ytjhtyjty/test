package ru.multienchant.filter;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.filter.FilterCatalogs.CatalogType;
import ru.multienchant.filter.FilterCatalogs.Category;
import ru.multienchant.locale.Messages;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * GUI чары «Фильтр»: главное меню категорий, постраничный просмотр материалов,
 * подтверждение отключения ценных материалов и «Отключить всё».
 *
 * Защита (§13 ТЗ):
 *  - все GUI-предметы — только иконки: любые способы взять/переместить блокируются
 *    (клики, shift-клики, drag, цифровые клавиши, offhand, double-click);
 *  - перед КАЖДЫМ изменением проверяется: предмет в основной руке, чара на месте,
 *    уникальный ID совпадает;
 *  - меню закрывается при смене слота, выбросе предмета, смерти, выходе, смене мира;
 *  - подтверждённые изменения пишутся в PDC сразу после клика;
 *  - неподтверждённое отключение ценного материала отменяется.
 */
public final class FilterMenuManager implements Listener {

    /** Текущий экран меню. */
    private enum View { MAIN, CATEGORY, CONFIRM_VALUABLE, CONFIRM_DISABLE_ALL }

    /** Состояние открытого меню; живёт в holder — внешних карт сессий нет. */
    private static final class Session {
        final UUID itemId;
        final CatalogType type;
        View view = View.MAIN;
        int categoryIndex = 0;
        int page = 0;
        Material pendingMaterial = null; // ожидает подтверждения (ценный материал)

        Session(UUID itemId, CatalogType type) {
            this.itemId = itemId;
            this.type = type;
        }
    }

    /** Holder — маркер наших инвентарей и носитель сессии. */
    private static final class MenuHolder implements InventoryHolder {
        final Session session;
        Inventory inventory;

        MenuHolder(Session session) {
            this.session = session;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final int CONTENT_SLOTS = 45; // 5 рядов материалов на страницу

    private final ConfigManager config;
    private final FilterStorage filterStorage;
    private final Messages messages;

    public FilterMenuManager(ConfigManager config, FilterStorage filterStorage, Messages messages) {
        this.config = config;
        this.filterStorage = filterStorage;
        this.messages = messages;
    }

    // ------------------------------------------------------------------
    // Открытие
    // ------------------------------------------------------------------

    /** Открывает главное меню для предмета в основной руке (проверки — на вызывающем). */
    public void open(Player player, ItemStack item) {
        CatalogType type = EnchantTarget.SWORD.matches(item.getType())
                ? CatalogType.MOBS : CatalogType.BLOCKS;
        UUID itemId = filterStorage.getOrCreateItemId(item);
        if (itemId == null) {
            return;
        }
        Session session = new Session(itemId, type);
        render(player, session);
    }

    // ------------------------------------------------------------------
    // Рендеринг экранов
    // ------------------------------------------------------------------

    private void render(Player player, Session session) {
        Inventory inv = switch (session.view) {
            case MAIN -> renderMain(session);
            case CATEGORY -> renderCategory(player, session);
            case CONFIRM_VALUABLE -> renderConfirmValuable(session);
            case CONFIRM_DISABLE_ALL -> renderConfirmDisableAll(session);
        };
        player.openInventory(inv);
    }

    private Inventory renderMain(Session session) {
        MenuHolder holder = new MenuHolder(session);
        Inventory inv = Bukkit.createInventory(holder, 27,
                plain(config.filter().guiTitle()));
        holder.inventory = inv;

        List<Category> categories = config.filterCatalogs().categories(session.type);
        Map<Integer, Integer> slots = mainMenuSlots(categories);
        for (Map.Entry<Integer, Integer> entry : slots.entrySet()) {
            Category category = categories.get(entry.getValue());
            inv.setItem(entry.getKey(), icon(category.icon(),
                    plain(category.title()).color(NamedTextColor.YELLOW),
                    List.of(gray(messages.raw("filter.gui.open-category")),
                            gray(messages.raw("filter.gui.materials-count",
                                    "count", String.valueOf(category.materials().size()))))));
        }

        if (config.filter().enableAllButton()) {
            inv.setItem(18, icon(Material.LIME_DYE,
                    green(messages.raw("filter.gui.enable-all")),
                    List.of(gray(messages.raw("filter.gui.enable-all-lore")))));
        }
        if (config.filter().disableAllButton()) {
            inv.setItem(26, icon(Material.RED_DYE,
                    red(messages.raw("filter.gui.disable-all")),
                    List.of(gray(messages.raw("filter.gui.disable-all-lore")),
                            gray(messages.raw("filter.gui.whole-catalog-note")))));
        }
        inv.setItem(22, icon(Material.BARRIER,
                red(messages.raw("filter.gui.close")), List.of()));
        return inv;
    }

    /**
     * Раскладка категорий в главном меню (27 слотов):
     * slot из filter-catalogs.yml имеет приоритет; категории без slot (или с
     * конфликтующим/недопустимым слотом) занимают свободные слоты 10..16 по порядку.
     * Служебные слоты 18 (вкл. всё), 22 (закрыть), 26 (откл. всё) заняты.
     */
    private Map<Integer, Integer> mainMenuSlots(List<Category> categories) {
        Map<Integer, Integer> result = new java.util.LinkedHashMap<>();
        List<Integer> autoIndices = new ArrayList<>();
        for (int i = 0; i < categories.size(); i++) {
            int slot = categories.get(i).slot();
            if (slot >= 0 && slot < 27 && slot != 18 && slot != 22 && slot != 26
                    && !result.containsKey(slot)) {
                result.put(slot, i);
            } else {
                autoIndices.add(i);
            }
        }
        int next = 10;
        for (int index : autoIndices) {
            while (next < 27 && (result.containsKey(next)
                    || next == 18 || next == 22 || next == 26)) {
                next++;
            }
            if (next >= 27) break; // все слоты заняты — лишние категории не показываем
            result.put(next, index);
        }
        return result;
    }

    private Inventory renderCategory(Player player, Session session) {
        List<Category> categories = config.filterCatalogs().categories(session.type);
        Category category = categories.get(session.categoryIndex);
        int pages = Math.max(1, (category.materials().size() + CONTENT_SLOTS - 1) / CONTENT_SLOTS);
        session.page = Math.min(session.page, pages - 1);

        MenuHolder holder = new MenuHolder(session);
        Inventory inv = Bukkit.createInventory(holder, 54,
                plain(config.filter().guiTitle() + " — " + category.title()));
        holder.inventory = inv;

        ItemStack handItem = player.getInventory().getItemInMainHand();
        EnumSet<Material> disabled = filterStorage.getDisabled(handItem);

        int from = session.page * CONTENT_SLOTS;
        int to = Math.min(from + CONTENT_SLOTS, category.materials().size());
        for (int i = from; i < to; i++) {
            Material material = category.materials().get(i);
            inv.setItem(i - from, materialIcon(material, !disabled.contains(material)));
        }

        // Нижний ряд навигации
        inv.setItem(45, icon(Material.ARROW,
                yellow(messages.raw("filter.gui.back")), List.of()));
        if (config.filter().enableAllButton()) {
            inv.setItem(46, icon(Material.LIME_DYE,
                    green(messages.raw("filter.gui.enable-all")),
                    List.of(gray(messages.raw("filter.gui.enable-all-lore")))));
        }
        if (session.page > 0) {
            inv.setItem(48, icon(Material.PAPER,
                    yellow(messages.raw("filter.gui.prev-page")), List.of()));
        }
        inv.setItem(49, icon(Material.MAP,
                yellow(messages.raw("filter.gui.page-info",
                        "page", String.valueOf(session.page + 1),
                        "pages", String.valueOf(pages))),
                List.of()));
        if (session.page < pages - 1) {
            inv.setItem(50, icon(Material.PAPER,
                    yellow(messages.raw("filter.gui.next-page")), List.of()));
        }
        if (config.filter().disableAllButton()) {
            inv.setItem(52, icon(Material.RED_DYE,
                    red(messages.raw("filter.gui.disable-all")),
                    List.of(gray(messages.raw("filter.gui.disable-all-lore")),
                            gray(messages.raw("filter.gui.whole-catalog-note")))));
        }
        inv.setItem(53, icon(Material.BARRIER,
                red(messages.raw("filter.gui.close")), List.of()));
        return inv;
    }

    private Inventory renderConfirmValuable(Session session) {
        MenuHolder holder = new MenuHolder(session);
        Inventory inv = Bukkit.createInventory(holder, 27,
                plain(messages.raw("filter.gui.confirm-title")));
        holder.inventory = inv;

        inv.setItem(13, icon(session.pendingMaterial,
                Component.translatable(session.pendingMaterial.translationKey())
                        .color(NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false),
                List.of(red(messages.raw("filter.gui.valuable-warning")),
                        red(messages.raw("filter.gui.destroy-warning")))));
        inv.setItem(11, icon(Material.LIME_WOOL,
                green(messages.raw("filter.gui.confirm-disable")),
                List.of(gray(messages.raw("filter.gui.confirm-disable-lore")))));
        inv.setItem(15, icon(Material.RED_WOOL,
                red(messages.raw("filter.gui.cancel")), List.of()));
        return inv;
    }

    private Inventory renderConfirmDisableAll(Session session) {
        MenuHolder holder = new MenuHolder(session);
        Inventory inv = Bukkit.createInventory(holder, 27,
                plain(messages.raw("filter.gui.confirm-title")));
        holder.inventory = inv;

        inv.setItem(13, icon(Material.RED_DYE,
                red(messages.raw("filter.gui.disable-all")),
                List.of(red(messages.raw("filter.gui.disable-all-warning")),
                        red(messages.raw("filter.gui.destroy-warning")),
                        gray(messages.raw("filter.gui.whole-catalog-note")))));
        inv.setItem(11, icon(Material.LIME_WOOL,
                green(messages.raw("filter.gui.confirm-disable")), List.of()));
        inv.setItem(15, icon(Material.RED_WOOL,
                red(messages.raw("filter.gui.cancel")), List.of()));
        return inv;
    }

    /** Иконка материала: русское название (translatable — клиент локализует) + статус. */
    private ItemStack materialIcon(Material material, boolean dropping) {
        List<Component> lore = new ArrayList<>();
        if (dropping) {
            lore.add(green(messages.raw("filter.gui.status-dropping")));
            lore.add(gray(messages.raw("filter.gui.click-to-disable")));
        } else {
            lore.add(red(messages.raw("filter.gui.status-removed")));
            lore.add(gray(messages.raw("filter.gui.click-to-enable")));
        }
        if (config.filterCatalogs().isValuable(material)) {
            lore.add(yellow(messages.raw("filter.gui.valuable-tag")));
        }
        Component name = Component.translatable(material.translationKey())
                .color(dropping ? NamedTextColor.GREEN : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false);
        return icon(material, name, lore);
    }

    private ItemStack icon(Material material, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(name.decoration(TextDecoration.ITALIC, false));
            if (!lore.isEmpty()) {
                meta.lore(lore);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static Component plain(String text) {
        return Component.text(text).decoration(TextDecoration.ITALIC, false);
    }

    private Component gray(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }

    private Component green(String text) {
        return Component.text(text, NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);
    }

    private Component red(String text) {
        return Component.text(text, NamedTextColor.RED).decoration(TextDecoration.ITALIC, false);
    }

    private Component yellow(String text) {
        return Component.text(text, NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false);
    }

    // ------------------------------------------------------------------
    // Обработка кликов
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof MenuHolder) {
            event.setCancelled(true); // никакого перетаскивания в наши меню
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MenuHolder holder)) {
            return;
        }
        // Иконки нельзя забрать НИКАКИМ способом: отменяем всё, включая
        // shift-клики из нижнего инвентаря, цифровые клавиши, offhand и double-click
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Клики по нижнему инвентарю игнорируем (но отменёнными оставляем)
        if (event.getClickedInventory() != event.getInventory()) return;

        Session session = holder.session;

        // §13: валидация перед каждым изменением
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType().isAir()
                || !filterStorage.hasFilter(hand)
                || !session.itemId.equals(filterStorage.peekItemId(hand))) {
            player.closeInventory();
            player.sendMessage(messages.get("filter.item-changed"));
            return;
        }

        int slot = event.getSlot();
        switch (session.view) {
            case MAIN -> clickMain(player, session, slot);
            case CATEGORY -> clickCategory(player, session, slot, hand);
            case CONFIRM_VALUABLE -> clickConfirmValuable(player, session, slot, hand);
            case CONFIRM_DISABLE_ALL -> clickConfirmDisableAll(player, session, slot, hand);
        }
    }

    private void clickMain(Player player, Session session, int slot) {
        List<Category> categories = config.filterCatalogs().categories(session.type);
        Integer categoryIndex = mainMenuSlots(categories).get(slot);
        if (categoryIndex != null) {
            session.categoryIndex = categoryIndex;
            session.page = 0;
            session.view = View.CATEGORY;
            click(player);
            render(player, session);
            return;
        }
        if (slot == 18 && config.filter().enableAllButton()) {
            enableAll(player, session);
            return;
        }
        if (slot == 26 && config.filter().disableAllButton()) {
            session.view = View.CONFIRM_DISABLE_ALL;
            click(player);
            render(player, session);
            return;
        }
        if (slot == 22) {
            player.closeInventory();
        }
    }

    private void clickCategory(Player player, Session session, int slot, ItemStack hand) {
        List<Category> categories = config.filterCatalogs().categories(session.type);
        Category category = categories.get(session.categoryIndex);

        if (slot < CONTENT_SLOTS) {
            int index = session.page * CONTENT_SLOTS + slot;
            if (index >= category.materials().size()) return;
            toggle(player, session, category.materials().get(index), hand);
            return;
        }
        switch (slot) {
            case 45 -> { // назад к категориям
                session.view = View.MAIN;
                click(player);
                render(player, session);
            }
            case 46 -> {
                if (config.filter().enableAllButton()) enableAll(player, session);
            }
            case 48 -> {
                if (session.page > 0) {
                    session.page--;
                    click(player);
                    render(player, session);
                }
            }
            case 50 -> {
                int pages = (category.materials().size() + CONTENT_SLOTS - 1) / CONTENT_SLOTS;
                if (session.page < pages - 1) {
                    session.page++;
                    click(player);
                    render(player, session);
                }
            }
            case 52 -> {
                if (config.filter().disableAllButton()) {
                    session.view = View.CONFIRM_DISABLE_ALL;
                    click(player);
                    render(player, session);
                }
            }
            case 53 -> player.closeInventory();
            default -> { /* пустой слот */ }
        }
    }

    private void toggle(Player player, Session session, Material material, ItemStack hand) {
        EnumSet<Material> disabled = filterStorage.getDisabled(hand);
        if (disabled.contains(material)) {
            // включаем обратно — подтверждение не требуется
            disabled.remove(material);
            filterStorage.setDisabled(hand, disabled);
            click(player);
            render(player, session);
            return;
        }
        // отключаем
        int limit = config.filter().maxDisabledMaterials();
        if (limit >= 0 && disabled.size() >= limit) {
            player.sendMessage(messages.format("filter.limit-reached",
                    Map.of("limit", String.valueOf(limit))));
            return;
        }
        if (config.filter().valuableConfirmation()
                && config.filterCatalogs().isValuable(material)) {
            // ценный материал: отдельное подтверждение (повторного клика недостаточно)
            session.pendingMaterial = material;
            session.view = View.CONFIRM_VALUABLE;
            click(player);
            render(player, session);
            return;
        }
        disabled.add(material);
        filterStorage.setDisabled(hand, disabled); // запись сразу после клика
        click(player);
        render(player, session);
    }

    private void clickConfirmValuable(Player player, Session session, int slot, ItemStack hand) {
        if (slot == 11 && session.pendingMaterial != null) {
            EnumSet<Material> disabled = filterStorage.getDisabled(hand);
            disabled.add(session.pendingMaterial);
            filterStorage.setDisabled(hand, disabled);
            session.pendingMaterial = null;
            session.view = View.CATEGORY;
            click(player);
            render(player, session);
        } else if (slot == 15) {
            // отмена: неподтверждённое изменение отбрасывается
            session.pendingMaterial = null;
            session.view = View.CATEGORY;
            click(player);
            render(player, session);
        }
    }

    private void clickConfirmDisableAll(Player player, Session session, int slot, ItemStack hand) {
        if (slot == 11) {
            // «Отключить всё» применяется ко ВСЕМУ каталогу предмета, не только к странице
            EnumSet<Material> disabled = filterStorage.getDisabled(hand);
            disabled.addAll(config.filterCatalogs().allMaterials(session.type));
            int limit = config.filter().maxDisabledMaterials();
            if (limit >= 0 && disabled.size() > limit) {
                player.sendMessage(messages.format("filter.limit-reached",
                        Map.of("limit", String.valueOf(limit))));
                session.view = View.MAIN;
                render(player, session);
                return;
            }
            filterStorage.setDisabled(hand, disabled);
            player.sendMessage(messages.get("filter.disabled-all"));
            session.view = View.MAIN;
            click(player);
            render(player, session);
        } else if (slot == 15) {
            session.view = View.MAIN;
            click(player);
            render(player, session);
        }
    }

    private void enableAll(Player player, Session session) {
        // «Включить всё» — без подтверждения: очищает список полностью
        ItemStack hand = player.getInventory().getItemInMainHand();
        filterStorage.reset(hand);
        player.sendMessage(messages.get("filter.enabled-all"));
        click(player);
        render(player, session);
    }

    private void click(Player player) {
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.0f);
    }

    // ------------------------------------------------------------------
    // Закрытие меню при потере контроля над предметом (§13 ТЗ)
    // ------------------------------------------------------------------

    private void closeIfOpen(Player player) {
        if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) {
            player.closeInventory();
        }
    }

    @EventHandler
    public void onHeldChange(PlayerItemHeldEvent event) {
        closeIfOpen(event.getPlayer());
    }

    @EventHandler
    public void onDropItem(PlayerDropItemEvent event) {
        closeIfOpen(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        closeIfOpen(event.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        closeIfOpen(event.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        closeIfOpen(event.getPlayer());
    }
}
