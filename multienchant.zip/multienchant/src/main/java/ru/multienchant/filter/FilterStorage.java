package ru.multienchant.filter;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.storage.PdcStorage;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Хранение настроек чары «Фильтр» в PDC конкретного предмета.
 *
 * Формат (версия 1):
 *   multienchant:filter_version  -> INTEGER (1)
 *   multienchant:filter_id       -> STRING  (UUID предмета)
 *   multienchant:filter_disabled -> STRING  (имена Material через запятую)
 *
 * Правила:
 *  - хранятся ТОЛЬКО стабильные имена Material (никаких русских названий);
 *  - неизвестные имена (из будущих версий игры) игнорируются при чтении,
 *    но не удаляются до следующей записи;
 *  - настройки принадлежат предмету: переживают смерть, перезапуск,
 *    ремонт, переименование, контейнеры и передачу другому игроку.
 */
public final class FilterStorage {

    public static final int FILTER_FORMAT_VERSION = 1;

    public static final NamespacedKey FILTER_VERSION_KEY = PdcStorage.key("filter_version");
    public static final NamespacedKey FILTER_ID_KEY = PdcStorage.key("filter_id");
    public static final NamespacedKey FILTER_DISABLED_KEY = PdcStorage.key("filter_disabled");

    private final PdcStorage storage;

    public FilterStorage(PdcStorage storage) {
        this.storage = storage;
    }

    /** Есть ли на предмете чара «Фильтр». */
    public boolean hasFilter(ItemStack item) {
        return storage.has(item, EnchantIds.FILTER);
    }

    /** Уникальный ID предмета; создаётся и записывается при первом обращении. */
    public UUID getOrCreateItemId(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String raw = pdc.get(FILTER_ID_KEY, PersistentDataType.STRING);
        if (raw != null) {
            try {
                return UUID.fromString(raw);
            } catch (IllegalArgumentException ignored) {
                // повреждённый id — перегенерируем ниже
            }
        }
        UUID id = UUID.randomUUID();
        pdc.set(FILTER_ID_KEY, PersistentDataType.STRING, id.toString());
        pdc.set(FILTER_VERSION_KEY, PersistentDataType.INTEGER, FILTER_FORMAT_VERSION);
        item.setItemMeta(meta);
        return id;
    }

    /** Текущий ID предмета без создания (null, если не назначен). */
    public UUID peekItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        String raw = item.getItemMeta().getPersistentDataContainer()
                .get(FILTER_ID_KEY, PersistentDataType.STRING);
        if (raw == null) {
            return null;
        }
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Назначить предмету НОВЫЙ уникальный ID (после наковальни — чтобы не было дублей). */
    public void regenerateItemId(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(FILTER_ID_KEY, PersistentDataType.STRING, UUID.randomUUID().toString());
        pdc.set(FILTER_VERSION_KEY, PersistentDataType.INTEGER, FILTER_FORMAT_VERSION);
        item.setItemMeta(meta);
    }

    /** Версия PDC-формата фильтра (0 — не записана). */
    public int formatVersion(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return 0;
        }
        Integer v = item.getItemMeta().getPersistentDataContainer()
                .get(FILTER_VERSION_KEY, PersistentDataType.INTEGER);
        return v == null ? 0 : v;
    }

    /**
     * Отключённые материалы предмета. По умолчанию (нет записи) — пустой набор:
     * весь дроп выпадает. Неизвестные имена материалов игнорируются.
     */
    public EnumSet<Material> getDisabled(ItemStack item) {
        EnumSet<Material> result = EnumSet.noneOf(Material.class);
        if (item == null || !item.hasItemMeta()) {
            return result;
        }
        String raw = item.getItemMeta().getPersistentDataContainer()
                .get(FILTER_DISABLED_KEY, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) {
            return result;
        }
        for (String name : raw.split(",")) {
            Material material = Material.matchMaterial(name.trim());
            if (material != null) {
                result.add(material);
            }
        }
        return result;
    }

    /** Полная запись списка отключённых материалов (вызывается после подтверждённого изменения). */
    public void setDisabled(ItemStack item, Set<Material> disabled) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        if (disabled.isEmpty()) {
            pdc.remove(FILTER_DISABLED_KEY);
        } else {
            StringBuilder sb = new StringBuilder();
            for (Material material : disabled) {
                if (sb.length() > 0) sb.append(',');
                sb.append(material.name());
            }
            pdc.set(FILTER_DISABLED_KEY, PersistentDataType.STRING, sb.toString());
        }
        pdc.set(FILTER_VERSION_KEY, PersistentDataType.INTEGER, FILTER_FORMAT_VERSION);
        item.setItemMeta(meta);
    }

    /** Сброс фильтра: весь дроп снова выпадает. */
    public void reset(ItemStack item) {
        setDisabled(item, EnumSet.noneOf(Material.class));
    }

    /**
     * Инициализация ПУСТОГО фильтра при наложении книги «Фильтр» (§14 ТЗ):
     * новый список (всё включено) и новый уникальный ID.
     */
    public void initEmpty(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.remove(FILTER_DISABLED_KEY);
        pdc.set(FILTER_ID_KEY, PersistentDataType.STRING, UUID.randomUUID().toString());
        pdc.set(FILTER_VERSION_KEY, PersistentDataType.INTEGER, FILTER_FORMAT_VERSION);
        item.setItemMeta(meta);
    }
}
