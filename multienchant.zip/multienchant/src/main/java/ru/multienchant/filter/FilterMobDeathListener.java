package ru.multienchant.filter;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.storage.PdcStorage;

import java.util.Set;

/**
 * Фильтрация дропа мобов для мечей с чарой «Фильтр».
 *
 * Условия срабатывания (все обязательны):
 *  - погибшая сущность НЕ игрок (дроп игроков никогда не фильтруется — PvP-защита);
 *  - моб убит игроком (getKiller() != null);
 *  - последний удар — прямой ближний удар этого игрока (EntityDamageByEntityEvent,
 *    damager == killer; стрелы/питомцы/падение/окружение — не проходят);
 *  - в основной руке убийцы — меч с чарой «Фильтр».
 *
 * Обрабатывается весь стандартный список дропа (обычный, редкий, экипировка,
 * подобранные предметы) — сравнение ТОЛЬКО по Material, метаданные игнорируются.
 * Опыт (droppedExp) не изменяется. Сторонний дроп: NORMAL-приоритет — предметы,
 * добавленные плагинами на более позднем приоритете, остаются нетронутыми;
 * при сомнении в происхождении предмет сохраняется.
 */
public final class FilterMobDeathListener implements Listener {

    private final ConfigManager config;
    private final PdcStorage storage;
    private final FilterStorage filterStorage;
    private final FilterService filterService;

    public FilterMobDeathListener(ConfigManager config, PdcStorage storage,
                                  FilterStorage filterStorage, FilterService filterService) {
        this.config = config;
        this.storage = storage;
        this.filterStorage = filterStorage;
        this.filterService = filterService;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        if (!config.filter().enabled()) return;

        // Дроп игроков НИКОГДА не фильтруется (это правило нельзя отключить)
        if (event.getEntity() instanceof Player) return;

        Player killer = event.getEntity().getKiller();
        if (killer == null) return;

        // Последний удар должен быть ПРЯМЫМ ударом игрока (не стрела, не питомец,
        // не падение/окружение): damager внутри последнего урона — сам игрок.
        if (!(event.getEntity().getLastDamageCause()
                instanceof EntityDamageByEntityEvent damage)) return;
        if (!damage.getDamager().equals(killer)) return;

        // Меч с «Фильтром» в ОСНОВНОЙ руке в момент смерти
        ItemStack weapon = killer.getInventory().getItemInMainHand();
        if (weapon.getType().isAir()) return;
        if (!EnchantTarget.SWORD.matches(weapon.getType())) return;
        if (!storage.has(weapon, EnchantIds.FILTER)) return;

        Set<Material> disabled = filterStorage.getDisabled(weapon);
        if (disabled.isEmpty()) return;

        // Только предметный дроп; droppedExp не трогаем
        event.getDrops().removeIf(drop -> filterService.isFiltered(drop, disabled));
    }
}
