package ru.multienchant.filter;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Каталоги материалов для GUI чары «Фильтр», загружаемые из filter-catalogs.yml
 * ОДИН раз при запуске/перезагрузке (никакого сканирования всех материалов игры
 * или рецептов при кликах — только готовые кешированные списки).
 */
public final class FilterCatalogs {

    /** Тип каталога: дроп мобов (мечи) или дроп блоков (инструменты). */
    public enum CatalogType { MOBS, BLOCKS }

    /**
     * Категория каталога: заголовок, иконка, слот в главном меню GUI
     * (slot: -1 — авторазмещение по порядку) и упорядоченный список материалов.
     */
    public record Category(String id, String title, Material icon, int slot,
                           List<Material> materials) {
    }

    private final List<Category> mobCategories;
    private final List<Category> blockCategories;
    private final EnumSet<Material> valuable;
    private final EnumSet<Material> allMobMaterials;
    private final EnumSet<Material> allBlockMaterials;

    private FilterCatalogs(List<Category> mobCategories, List<Category> blockCategories,
                           EnumSet<Material> valuable) {
        this.mobCategories = Collections.unmodifiableList(mobCategories);
        this.blockCategories = Collections.unmodifiableList(blockCategories);
        this.valuable = valuable;
        this.allMobMaterials = collect(mobCategories);
        this.allBlockMaterials = collect(blockCategories);
    }

    private static EnumSet<Material> collect(List<Category> categories) {
        EnumSet<Material> set = EnumSet.noneOf(Material.class);
        for (Category category : categories) {
            set.addAll(category.materials());
        }
        return set;
    }

    /** Разбор корня filter-catalogs.yml. Неизвестные материалы пропускаются с предупреждением. */
    public static FilterCatalogs parse(ConfigurationSection root, java.util.logging.Logger logger) {
        EnumSet<Material> valuable = EnumSet.noneOf(Material.class);
        for (String name : root.getStringList("valuable-materials")) {
            Material material = Material.matchMaterial(name.trim());
            if (material != null) {
                valuable.add(material);
            } else {
                logger.warning("[MultiEnchant] filter-catalogs.yml: неизвестный материал '" + name + "' в valuable-materials");
            }
        }
        List<Category> mobs = parseCatalog(root.getConfigurationSection("catalogs.mobs"), logger);
        List<Category> blocks = parseCatalog(root.getConfigurationSection("catalogs.blocks"), logger);
        return new FilterCatalogs(mobs, blocks, valuable);
    }

    private static List<Category> parseCatalog(ConfigurationSection section,
                                               java.util.logging.Logger logger) {
        List<Category> result = new ArrayList<>();
        if (section == null) {
            return result;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection cat = section.getConfigurationSection(id);
            if (cat == null) continue;
            String title = cat.getString("title", id);
            Material icon = Material.matchMaterial(cat.getString("icon", "CHEST"));
            if (icon == null) {
                icon = Material.CHEST;
            }
            int slot = cat.getInt("slot", -1); // -1 — авторазмещение
            List<Material> materials = new ArrayList<>();
            for (String name : cat.getStringList("materials")) {
                Material material = Material.matchMaterial(name.trim());
                if (material != null) {
                    if (!materials.contains(material)) {
                        materials.add(material); // материал показывается один раз
                    }
                } else {
                    logger.warning("[MultiEnchant] filter-catalogs.yml: неизвестный материал '"
                            + name + "' в категории '" + id + "'");
                }
            }
            result.add(new Category(id, title, icon, slot, materials));
        }
        return result;
    }

    public List<Category> categories(CatalogType type) {
        return type == CatalogType.MOBS ? mobCategories : blockCategories;
    }

    /** Все материалы каталога (для «Отключить всё» на весь каталог, а не страницу). */
    public Set<Material> allMaterials(CatalogType type) {
        return Collections.unmodifiableSet(
                type == CatalogType.MOBS ? allMobMaterials : allBlockMaterials);
    }

    public boolean isValuable(Material material) {
        return valuable.contains(material);
    }
}
