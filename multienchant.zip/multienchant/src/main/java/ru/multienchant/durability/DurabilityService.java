package ru.multienchant.durability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;

/**
 * Расход прочности инструмента через Paper API:
 * Player#damageItemStack учитывает Разрушаемость (Unbreaking),
 * вызывает PlayerItemDamageEvent и корректно ломает предмет.
 */
public final class DurabilityService {

    /**
     * Наносит урон предмету в основной руке.
     *
     * @return true, если инструмент сломался (дальнейшую обработку нужно прекратить)
     */
    public boolean damageMainHand(Player player, int amount) {
        player.damageItemStack(EquipmentSlot.HAND, amount);
        return player.getInventory().getItemInMainHand().getType().isAir();
    }
}
