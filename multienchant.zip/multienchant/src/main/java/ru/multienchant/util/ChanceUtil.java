package ru.multienchant.util;

import java.util.Map;
import java.util.Random;

/** Чистая вероятностная логика (без зависимостей от Bukkit — покрыта unit-тестами). */
public final class ChanceUtil {

    private ChanceUtil() {
    }

    /** Бросок шанса с ThreadLocalRandom (для продакшен-кода). */
    public static boolean roll(double percent) {
        return roll(percent, java.util.concurrent.ThreadLocalRandom.current());
    }

    /** Вероятностное округление с ThreadLocalRandom (для продакшен-кода). */
    public static int probabilisticRound(double value) {
        return probabilisticRound(value, java.util.concurrent.ThreadLocalRandom.current());
    }

    /** Взвешенный выбор уровня с ThreadLocalRandom (для продакшен-кода). */
    public static int pickWeightedLevel(Map<Integer, Double> weights) {
        return pickWeightedLevel(weights, java.util.concurrent.ThreadLocalRandom.current());
    }

    /** Случайный индекс [0..bound). */
    public static int randomIndex(int bound) {
        return java.util.concurrent.ThreadLocalRandom.current().nextInt(Math.max(1, bound));
    }

    /** Взвешенный выбор уровня с клампом по maxLevel чары. */
    public static int weightedLevel(Map<Integer, Double> weights, int maxLevel) {
        return Math.max(1, Math.min(pickWeightedLevel(weights), maxLevel));
    }

    /** Бросок шанса в процентах [0..100]. 0 — никогда, 100 — всегда. */
    public static boolean roll(double percent, Random random) {
        if (percent <= 0.0) {
            return false;
        }
        if (percent >= 100.0) {
            return true;
        }
        return random.nextDouble() * 100.0 < percent;
    }

    /**
     * Вероятностное округление: 2.6 -> 2 (40%) или 3 (60%).
     * Используется для дробного бонуса опыта.
     */
    public static int probabilisticRound(double value, Random random) {
        if (value <= 0.0) {
            return 0;
        }
        int floor = (int) Math.floor(value);
        double fraction = value - floor;
        if (fraction > 0.0 && random.nextDouble() < fraction) {
            return floor + 1;
        }
        return floor;
    }

    /**
     * Взвешенный выбор уровня из карты {уровень -> вес}.
     * Уровни с нулевым/отрицательным весом не выпадают. Пустая карта -> 1.
     */
    public static int pickWeightedLevel(Map<Integer, Double> weights, Random random) {
        double total = 0.0;
        for (double w : weights.values()) {
            if (w > 0.0) {
                total += w;
            }
        }
        if (total <= 0.0) {
            return 1;
        }
        double roll = random.nextDouble() * total;
        double acc = 0.0;
        for (Map.Entry<Integer, Double> e : weights.entrySet()) {
            if (e.getValue() <= 0.0) {
                continue;
            }
            acc += e.getValue();
            if (roll < acc) {
                return e.getKey();
            }
        }
        return 1;
    }
}
