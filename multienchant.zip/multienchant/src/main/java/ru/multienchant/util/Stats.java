package ru.multienchant.util;

import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

/** Внутренние счётчики производительности (выводятся в /me inspect). */
public final class Stats {

    private final ConcurrentHashMap<String, LongAdder> counters = new ConcurrentHashMap<>();

    public void inc(String key) {
        add(key, 1);
    }

    /** Синоним inc. */
    public void increment(String key) {
        add(key, 1);
    }

    /** Синоним snapshot: отсортированные счётчики для /me inspect. */
    public Map<String, Long> summary() {
        return snapshot();
    }

    public void add(String key, long amount) {
        counters.computeIfAbsent(key, k -> new LongAdder()).add(amount);
    }

    public Map<String, Long> snapshot() {
        Map<String, Long> result = new TreeMap<>();
        counters.forEach((key, adder) -> result.put(key, adder.sum()));
        return result;
    }
}
