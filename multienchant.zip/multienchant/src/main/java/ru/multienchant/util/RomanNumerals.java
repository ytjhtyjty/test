package ru.multienchant.util;

/** Римские цифры для уровней чар (как в ванильном lore). */
public final class RomanNumerals {

    private static final String[] TOKENS = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
    private static final int[] VALUES = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};

    private RomanNumerals() {
    }

    public static String toRoman(int value) {
        if (value <= 0) {
            return String.valueOf(value);
        }
        StringBuilder sb = new StringBuilder();
        int rest = value;
        for (int i = 0; i < VALUES.length; i++) {
            while (rest >= VALUES[i]) {
                rest -= VALUES[i];
                sb.append(TOKENS[i]);
            }
        }
        return sb.toString();
    }
}
