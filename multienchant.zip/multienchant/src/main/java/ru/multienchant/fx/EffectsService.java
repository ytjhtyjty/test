package ru.multienchant.fx;

import org.bukkit.Location;
import org.bukkit.Particle;
import ru.multienchant.config.ConfigManager;

import java.util.function.Supplier;

/**
 * Агрегированные звуки и частицы: один эффект на срабатывание механики,
 * а не на каждый обработанный блок (защита от спама эффектов).
 */
public final class EffectsService {

    private final Supplier<ConfigManager.Snapshot> config;

    public EffectsService(Supplier<ConfigManager.Snapshot> config) {
        this.config = config;
    }

    /** key — ключ секции effects в config.yml: drill, lumberjack, lava-walker, auto-smelt. */
    public void play(String key, Location location) {
        ConfigManager.Snapshot snapshot = config.get();
        if (!snapshot.effectsEnabled() || location.getWorld() == null) {
            return;
        }
        ConfigManager.EffectConfig effect = snapshot.effects().get(key);
        if (effect == null) {
            return;
        }
        if (effect.sound() != null && !effect.sound().isBlank()) {
            location.getWorld().playSound(location, effect.sound(), 1.0f, 1.0f);
        }
        if (effect.particles()) {
            location.getWorld().spawnParticle(Particle.POOF, location, 10, 0.5, 0.5, 0.5, 0.02);
        }
    }
}
