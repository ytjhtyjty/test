package ru.multienchant.pipeline;

import org.bukkit.Material;

import java.util.Map;
import java.util.Random;

/**
 * Ванильные значения опыта за добычу блоков (Java Edition 1.21).
 * Используется для дополнительных блоков Бура/Лесоруба: их разрушение
 * идёт мимо ванильной логики, поэтому опыт рассчитывается вручную.
 * При Шёлковом касании опыт всегда 0 (проверяется в конвейере).
 */
public final class BlockXpTable {

    /** {материал -> [min, max]} включительно. */
    private static final Map<Material, int[]> XP = Map.ofEntries(
            Map.entry(Material.COAL_ORE, new int[]{0, 2}),
            Map.entry(Material.DEEPSLATE_COAL_ORE, new int[]{0, 2}),
            Map.entry(Material.DIAMOND_ORE, new int[]{3, 7}),
            Map.entry(Material.DEEPSLATE_DIAMOND_ORE, new int[]{3, 7}),
            Map.entry(Material.EMERALD_ORE, new int[]{3, 7}),
            Map.entry(Material.DEEPSLATE_EMERALD_ORE, new int[]{3, 7}),
            Map.entry(Material.LAPIS_ORE, new int[]{2, 5}),
            Map.entry(Material.DEEPSLATE_LAPIS_ORE, new int[]{2, 5}),
            Map.entry(Material.NETHER_QUARTZ_ORE, new int[]{2, 5}),
            Map.entry(Material.REDSTONE_ORE, new int[]{1, 5}),
            Map.entry(Material.DEEPSLATE_REDSTONE_ORE, new int[]{1, 5}),
            Map.entry(Material.NETHER_GOLD_ORE, new int[]{0, 1}),
            Map.entry(Material.SCULK, new int[]{1, 1}),
            Map.entry(Material.SCULK_SENSOR, new int[]{5, 5}),
            Map.entry(Material.CALIBRATED_SCULK_SENSOR, new int[]{5, 5}),
            Map.entry(Material.SCULK_CATALYST, new int[]{5, 5}),
            Map.entry(Material.SCULK_SHRIEKER, new int[]{5, 5}),
            Map.entry(Material.SPAWNER, new int[]{15, 43})
    );

    private BlockXpTable() {
    }

    /** Случайное ванильное значение опыта за блок с ThreadLocalRandom. */
    public static int vanillaXp(Material material) {
        return vanillaXp(material, java.util.concurrent.ThreadLocalRandom.current());
    }

    /** Случайное ванильное значение опыта за блок (0 для блоков без опыта). */
    public static int vanillaXp(Material material, Random random) {
        int[] range = XP.get(material);
        if (range == null) {
            return 0;
        }
        if (range[0] == range[1]) {
            return range[0];
        }
        return range[0] + random.nextInt(range[1] - range[0] + 1);
    }
}
