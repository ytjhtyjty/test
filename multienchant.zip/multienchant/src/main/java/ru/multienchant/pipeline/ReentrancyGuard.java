package ru.multienchant.pipeline;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Защита от рекурсии: пока конвейер обрабатывает дополнительные блоки
 * (Бур/Лесоруб), внутренние BlockBreakEvent для этих блоков не должны
 * повторно запускать механики. Потокобезопасно (Folia/асинхронные плагины).
 */
public final class ReentrancyGuard {

    private final Set<UUID> active = ConcurrentHashMap.newKeySet();

    public boolean isActive(UUID playerId) {
        return active.contains(playerId);
    }

    /** Синоним isActive: находится ли игрок внутри конвейера. */
    public boolean isInside(UUID playerId) {
        return active.contains(playerId);
    }

    public void enter(UUID playerId) {
        active.add(playerId);
    }

    public void exit(UUID playerId) {
        active.remove(playerId);
    }
}
