package ru.multienchant.pipeline;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import ru.multienchant.config.ConfigManager;
import ru.multienchant.durability.DurabilityService;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.fx.EffectsService;
import ru.multienchant.integration.IntegrationManager;
import ru.multienchant.util.ChanceUtil;
import ru.multienchant.util.Stats;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Единый конвейер обработки разрушения блоков.
 *
 * Порядок для каждого блока:
 *   дроп (Удача/Шёлк) -> Автоплавка -> накопление XP (ваниль + чара "Опыт")
 * Затем агрегированно:
 *   Магнит (доставка в инвентарь / остаток на землю) или обычный спавн дропа,
 *   один орб опыта, один набор эффектов.
 *
 * Конвейер гарантирует отсутствие дюпов: ванильный дроп/XP центрального блока
 * отменяется вызывающим слушателем, и весь дроп идёт только через конвейер.
 */
public final class BlockBreakPipeline {

    private final ConfigManager config;
    private final DropCalculator dropCalculator;
    private final SmeltService smeltService;
    private final MagnetService magnetService;
    private final DurabilityService durabilityService;
    private final EffectsService effectsService;
    private final IntegrationManager integrations;
    private final ReentrancyGuard guard;
    private final Stats stats;
    private final ru.multienchant.filter.FilterService filterService;
    private final ru.multienchant.filter.FilterStorage filterStorage;

    public BlockBreakPipeline(ConfigManager config,
                              DropCalculator dropCalculator,
                              SmeltService smeltService,
                              MagnetService magnetService,
                              DurabilityService durabilityService,
                              EffectsService effectsService,
                              IntegrationManager integrations,
                              ReentrancyGuard guard,
                              Stats stats,
                              ru.multienchant.filter.FilterService filterService,
                              ru.multienchant.filter.FilterStorage filterStorage) {
        this.config = config;
        this.dropCalculator = dropCalculator;
        this.smeltService = smeltService;
        this.magnetService = magnetService;
        this.durabilityService = durabilityService;
        this.effectsService = effectsService;
        this.integrations = integrations;
        this.guard = guard;
        this.stats = stats;
        this.filterService = filterService;
        this.filterStorage = filterStorage;
    }

    /** Результат обработки одного блока конвейером. */
    public record BlockResult(List<ItemStack> drops, int xp, boolean toolBroke) {}

    /**
     * Полная обработка срабатывания механики (Бур/Лесоруб) вместе с центральным блоком.
     *
     * @param event        исходное (внешнее) событие разрушения центрального блока
     * @param extraBlocks  дополнительные блоки (могут быть пустыми)
     * @param enchants     чары инструмента (id -> уровень), уже прочитанные из PDC
     * @param effectKey    ключ секции эффектов в config.yml ("drill" / "lumberjack")
     */
    public void processTrigger(BlockBreakEvent event,
                               List<Block> extraBlocks,
                               Map<String, Integer> enchants,
                               String effectKey) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();

        boolean hasMagnet = enchants.containsKey(EnchantIds.MAGNET);
        boolean hasSmelt = enchants.containsKey(EnchantIds.AUTO_SMELT);
        int xpLevel = enchants.getOrDefault(EnchantIds.EXPERIENCE, 0);

        // Фильтр: читаем отключённые материалы ОДИН раз на всё срабатывание
        java.util.Set<org.bukkit.Material> filterDisabled =
                (enchants.containsKey(EnchantIds.FILTER) && config.filter().enabled())
                        ? filterStorage.getDisabled(tool)
                        : java.util.Collections.emptySet();

        List<ItemStack> aggregatedDrops = new ArrayList<>();
        int aggregatedXp = 0;
        Location center = event.getBlock().getLocation().toCenterLocation();

        // --- Центральный блок: отменяем ванильный дроп и XP, ведём через конвейер ---
        event.setDropItems(false);
        int vanillaCenterXp = event.getExpToDrop();
        event.setExpToDrop(0);

        BlockResult centerResult = processSingleBlock(event.getBlock(), player, tool,
                hasSmelt, xpLevel, vanillaCenterXp, false, filterDisabled);
        aggregatedDrops.addAll(centerResult.drops());
        aggregatedXp += centerResult.xp();

        // --- Дополнительные блоки ---
        boolean toolBroke = false;
        int processed = 0;
        guard.enter(player.getUniqueId());
        try {
            for (Block extra : extraBlocks) {
                if (toolBroke) break;
                if (!isBreakable(extra, player, tool)) continue;

                // Внутреннее событие: даём другим плагинам шанс отменить конкретный блок
                BlockBreakEvent inner = new BlockBreakEvent(extra, player);
                inner.setDropItems(false);
                player.getServer().getPluginManager().callEvent(inner);
                if (inner.isCancelled()) continue;

                int vanillaXp = inner.getExpToDrop();
                inner.setExpToDrop(0);

                BlockResult r = processSingleBlock(extra, player, tool,
                        hasSmelt, xpLevel, vanillaXp, true, filterDisabled);
                aggregatedDrops.addAll(r.drops());
                aggregatedXp += r.xp();
                processed++;

                // Расход прочности: 1 ед. на каждый дополнительный блок
                if (player.getGameMode() != GameMode.CREATIVE) {
                    toolBroke = durabilityService.damageMainHand(player, 1);
                }
            }
        } finally {
            guard.exit(player.getUniqueId());
        }

        // --- Агрегированная доставка ---
        if (hasMagnet && config.magnet().enabled()) {
            magnetService.deliver(player, aggregatedDrops);
        } else {
            for (ItemStack drop : aggregatedDrops) {
                center.getWorld().dropItemNaturally(center, drop);
            }
        }

        if (aggregatedXp > 0) {
            Location xpLoc = hasMagnet ? player.getLocation() : center;
            final int xpValue = aggregatedXp;
            // Консьюмер применяется ДО добавления сущности в мир — значение задаётся атомарно
            xpLoc.getWorld().spawn(xpLoc, ExperienceOrb.class, orb -> orb.setExperience(xpValue));
        }

        if (processed > 0) {
            effectsService.play(effectKey, center);
            stats.increment(effectKey + ".triggers");
            stats.add(effectKey + ".blocks", processed);
        }
    }

    /**
     * Обработка одного блока: дроп -> автоплавка -> XP. Блок удаляется из мира (для доп. блоков).
     */
    private BlockResult processSingleBlock(Block block, Player player, ItemStack tool,
                                           boolean hasSmelt, int xpLevel,
                                           int vanillaXp, boolean removeBlock,
                                           java.util.Set<org.bukkit.Material> filterDisabled) {
        boolean silk = tool.containsEnchantment(Enchantment.SILK_TOUCH);

        List<ItemStack> drops = dropCalculator.dropsFor(block, tool, player);

        // Порядок Автоплавка/Фильтр настраивается (processing-order в enchants.yml)
        boolean smeltFirst = config.filter().autoSmeltBeforeFilter();
        if (!smeltFirst) {
            filterService.filterDrops(drops, filterDisabled);
        }

        // Автоплавка: при Шёлке в режиме silk-priority дроп не переплавляется
        if (hasSmelt && config.autoSmelt().enabled()
                && !(silk && config.autoSmelt().silkPriority())) {
            drops = smeltService.transform(drops);
        }

        // Фильтр после Автоплавки (по умолчанию): отключённый IRON_INGOT
        // удалит и переплавленный слиток. Всегда ДО Магнита. Опыт не трогаем.
        if (smeltFirst) {
            filterService.filterDrops(drops, filterDisabled);
        }

        int xp = silk ? 0 : vanillaXp;
        if (xp == 0 && removeBlock && !silk) {
            // для доп. блоков ванильный XP из внутреннего события может быть не заполнен —
            // используем таблицу ванильных значений
            xp = BlockXpTable.vanillaXp(block.getType());
        }
        if (xpLevel > 0 && xp > 0) {
            double bonus = config.experience().oreBonusPercent(xpLevel) / 100.0;
            xp += ChanceUtil.probabilisticRound(xp * bonus);
        }

        if (removeBlock) {
            block.setType(Material.AIR, true);
        }
        return new BlockResult(drops, xp, false);
    }

    /** Проверки допустимости разрушения дополнительного блока. */
    public boolean isBreakable(Block block, Player player, ItemStack tool) {
        if (block.getType().isAir()) return false;
        if (!block.getChunk().isLoaded()) return false;
        if (block.getType().getHardness() < 0) return false; // бедрок и т.п.
        if (block.getState() instanceof Container) return false; // контейнеры не трогаем
        if (!block.isPreferredTool(tool)) return false;
        if (!integrations.canBreak(player, block)) return false;
        return true;
    }
}
