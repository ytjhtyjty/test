package ru.multienchant.pipeline;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;

/**
 * Магнит: доставка дропа напрямую в инвентарь игрока.
 * Что не поместилось — выпадает на землю рядом с игроком (принятое решение по ТЗ).
 */
public final class MagnetService {

    /** Кладёт предметы в инвентарь; остаток выбрасывает у ног игрока. Возвращает true, если всё поместилось. */
    public boolean deliver(Player player, List<ItemStack> drops) {
        boolean allFit = true;
        for (ItemStack drop : drops) {
            if (drop == null || drop.getType().isAir() || drop.getAmount() <= 0) {
                continue;
            }
            HashMap<Integer, ItemStack> leftovers = player.getInventory().addItem(drop);
            for (ItemStack leftover : leftovers.values()) {
                allFit = false;
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
        }
        return allFit;
    }
}
