package ru.multienchant.pipeline;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.BlastingRecipe;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Автоплавка: кеш рецептов печи/плавильни, построенный из реестра сервера
 * (Bukkit.recipeIterator()) — никаких жёстких списков; кастомные рецепты
 * других плагинов и датапаков учитываются автоматически.
 */
public final class SmeltService {

    /** Результат плавки: предмет-результат и опыт печи за единицу. */
    public record SmeltResult(ItemStack result, float furnaceXp) {
    }

    private final Map<Material, SmeltResult> cache = new ConcurrentHashMap<>();
    private volatile boolean loaded = false;

    /** Построение кеша; вызывается в onEnable и при /me reload. */
    public void rebuildCache() {
        Map<Material, SmeltResult> fresh = new ConcurrentHashMap<>();
        Iterator<Recipe> it = Bukkit.recipeIterator();
        while (it.hasNext()) {
            Recipe recipe = it.next();
            RecipeChoice choice;
            float xp;
            if (recipe instanceof BlastingRecipe blasting) {
                choice = blasting.getInputChoice();
                xp = blasting.getExperience();
            } else if (recipe instanceof FurnaceRecipe furnace) {
                choice = furnace.getInputChoice();
                xp = furnace.getExperience();
            } else {
                continue;
            }
            if (choice instanceof RecipeChoice.MaterialChoice materialChoice) {
                for (Material input : materialChoice.getChoices()) {
                    // FurnaceRecipe не перезаписывает BlastingRecipe и наоборот — берём первый найденный
                    fresh.putIfAbsent(input, new SmeltResult(recipe.getResult(), xp));
                }
            } else if (choice instanceof RecipeChoice.ExactChoice exactChoice) {
                for (ItemStack input : exactChoice.getChoices()) {
                    fresh.putIfAbsent(input.getType(), new SmeltResult(recipe.getResult(), xp));
                }
            }
        }
        cache.clear();
        cache.putAll(fresh);
        loaded = true;
    }

    /** Синоним rebuildCache. */
    public void buildRecipeCache() {
        rebuildCache();
    }

    public int cacheSize() {
        return cache.size();
    }

    public boolean isLoaded() {
        return loaded;
    }

    /** Есть ли рецепт плавки для материала. */
    public boolean canSmelt(Material material) {
        return cache.containsKey(material);
    }

    /**
     * Трансформация дропа: каждый стак, для которого есть рецепт,
     * заменяется результатом плавки (количество сохраняется);
     * остальные стаки возвращаются без изменений.
     */
    public List<ItemStack> transform(List<ItemStack> drops) {
        return drops.stream().map(stack -> {
            SmeltResult smelt = cache.get(stack.getType());
            if (smelt == null) {
                return stack;
            }
            ItemStack result = smelt.result().clone();
            result.setAmount(smelt.result().getAmount() * stack.getAmount());
            return result;
        }).toList();
    }

    /** Суммарный опыт печи за список дропа (для режима furnace-xp). */
    public double furnaceXp(List<ItemStack> drops) {
        double total = 0.0;
        for (ItemStack stack : drops) {
            SmeltResult smelt = cache.get(stack.getType());
            if (smelt != null) {
                total += smelt.furnaceXp() * stack.getAmount();
            }
        }
        return total;
    }
}
