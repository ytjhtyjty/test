package ru.multienchant.pipeline;

import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Расчёт дропа блока с учётом ванильных чар инструмента (Удача, Шёлк)
 * через Block#getDrops — используются серверные таблицы лута, поэтому
 * кастомные датапаки и другие плагины учитываются автоматически.
 */
public final class DropCalculator {

    /** Обычный дроп: ванильная логика для данного инструмента. */
    public List<ItemStack> dropsFor(Block block, ItemStack tool, Player player) {
        return new ArrayList<>(block.getDrops(tool, player));
    }

    /**
     * Дроп без учёта Удачи (режим Автоплавки fortune-mode: smelt-only):
     * считается клоном инструмента с удалённой Удачей.
     */
    public List<ItemStack> dropsWithoutFortune(Block block, ItemStack tool, Player player) {
        if (!tool.containsEnchantment(Enchantment.FORTUNE)) {
            return dropsFor(block, tool, player);
        }
        ItemStack stripped = tool.clone();
        stripped.removeEnchantment(Enchantment.FORTUNE);
        return new ArrayList<>(block.getDrops(stripped, player));
    }
}
