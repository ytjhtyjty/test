package ru.multienchant.storage;

import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantRegistry;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Хранение кастомных чар в PersistentDataContainer предмета.
 *
 * Формат (версия 1):
 *   multienchant:version  -> INTEGER
 *   multienchant:enchants -> TAG_CONTAINER { multienchant:<id> -> INTEGER (уровень) }
 *
 * Правила устойчивости:
 *  - неизвестные ключи (чужие плагины / будущие версии) никогда не удаляются;
 *  - уровень вне [1..max] клампится при чтении и исправляется при следующей записи;
 *  - все операции записи проходят через setEnchant/removeEnchant (точечное изменение).
 */
public final class PdcStorage {

    public static final String NAMESPACE = "multienchant";
    public static final int FORMAT_VERSION = 1;

    public static final NamespacedKey VERSION_KEY = key("version");
    public static final NamespacedKey ENCHANTS_KEY = key("enchants");
    public static final NamespacedKey BOOK_KEY = key("book");
    public static final NamespacedKey LORE_LINES_KEY = key("lore_lines");
    public static final NamespacedKey XP_WEAPON_LEVEL_KEY = key("xp_weapon_level");
    public static final NamespacedKey TRADE_MARKER_KEY = key("trade");

    public static NamespacedKey key(String value) {
        return new NamespacedKey(NAMESPACE, value);
    }

    private final EnchantRegistry registry;
    private final Logger logger;

    public PdcStorage(EnchantRegistry registry, Logger logger) {
        this.registry = registry;
        this.logger = logger;
    }

    /** Синоним getEnchants. */
    public Map<String, Integer> readEnchants(ItemStack item) {
        return getEnchants(item);
    }

    /** Синоним getRawEnchants. */
    public Map<String, Integer> readEnchantsRaw(ItemStack item) {
        return getRawEnchants(item);
    }

    /** Валидные чары предмета: только зарегистрированные id, уровни в допустимом диапазоне. */
    public Map<String, Integer> getEnchants(ItemStack item) {
        Map<String, Integer> result = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : getRawEnchants(item).entrySet()) {
            CustomEnchant enchant = registry.byId(entry.getKey()).orElse(null);
            if (enchant == null) {
                continue; // неизвестный id: сохраняем в PDC, но не используем
            }
            int level = entry.getValue();
            if (!enchant.isValidLevel(level)) {
                int clamped = enchant.clampLevel(level);
                logger.warning("[MultiEnchant] Повреждённый уровень чары '" + entry.getKey()
                        + "' (" + level + ") приведён к " + clamped);
                level = clamped;
            }
            result.put(entry.getKey(), level);
        }
        return result;
    }

    /** Сырые данные (включая неизвестные id и невалидные уровни) — для /me inspect. */
    public Map<String, Integer> getRawEnchants(ItemStack item) {
        Map<String, Integer> result = new LinkedHashMap<>();
        if (item == null || !item.hasItemMeta()) {
            return result;
        }
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer()
                .get(ENCHANTS_KEY, PersistentDataType.TAG_CONTAINER);
        if (container == null) {
            return result;
        }
        for (NamespacedKey key : container.getKeys()) {
            if (!NAMESPACE.equals(key.getNamespace())) {
                continue;
            }
            Integer level = container.get(key, PersistentDataType.INTEGER);
            if (level != null) {
                result.put(key.getKey(), level);
            }
        }
        return result;
    }

    public int getLevel(ItemStack item, String enchantId) {
        return getEnchants(item).getOrDefault(enchantId, 0);
    }

    public boolean has(ItemStack item, String enchantId) {
        return getLevel(item, enchantId) > 0;
    }

    /**
     * Полная перезапись набора кастомных чар предмета.
     * Неизвестные (чужие/будущие) ключи в контейнере сохраняются нетронутыми.
     */
    public void writeEnchants(ItemStack item, Map<String, Integer> enchants) {
        // Сначала удаляем наши прежние валидные ключи, отсутствующие в новом наборе
        for (String existing : getRawEnchants(item).keySet()) {
            if (registry.contains(existing) && !enchants.containsKey(existing)) {
                removeEnchant(item, existing);
            }
        }
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            setEnchant(item, entry.getKey(), entry.getValue());
        }
    }

    /** Синоним markBook. */
    public void markAsBook(ItemStack book) {
        markBook(book);
    }

    /** Точечная запись уровня чары: остальные ключи контейнера не затрагиваются. */
    public void setEnchant(ItemStack item, String enchantId, int level) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        PersistentDataContainer container = pdc.get(ENCHANTS_KEY, PersistentDataType.TAG_CONTAINER);
        if (container == null) {
            container = pdc.getAdapterContext().newPersistentDataContainer();
        }
        container.set(key(enchantId), PersistentDataType.INTEGER, level);
        pdc.set(ENCHANTS_KEY, PersistentDataType.TAG_CONTAINER, container);
        pdc.set(VERSION_KEY, PersistentDataType.INTEGER, FORMAT_VERSION);
        item.setItemMeta(meta);
    }

    /** Удаление одной чары; пустой контейнер и служебные ключи зачищаются полностью. */
    public void removeEnchant(ItemStack item, String enchantId) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        PersistentDataContainer container = pdc.get(ENCHANTS_KEY, PersistentDataType.TAG_CONTAINER);
        if (container == null) {
            return;
        }
        container.remove(key(enchantId));
        if (container.getKeys().isEmpty()) {
            pdc.remove(ENCHANTS_KEY);
            pdc.remove(VERSION_KEY);
        } else {
            pdc.set(ENCHANTS_KEY, PersistentDataType.TAG_CONTAINER, container);
        }
        item.setItemMeta(meta);
    }

    /** Маркировка зачарованной книги как кастомной. */
    public void markBook(ItemStack book) {
        ItemMeta meta = book.getItemMeta();
        if (meta == null) {
            return;
        }
        meta.getPersistentDataContainer().set(BOOK_KEY, PersistentDataType.INTEGER, 1);
        book.setItemMeta(meta);
    }

    public boolean isCustomBook(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer()
                .has(BOOK_KEY, PersistentDataType.INTEGER);
    }

    /**
     * Все id чар предмета для проверки конфликтов:
     * кастомные ("drill") + ванильные ("minecraft:silk_touch"),
     * включая хранимые чары зачарованной книги.
     */
    public Set<String> allPresentIds(ItemStack item) {
        Set<String> ids = new LinkedHashSet<>(getEnchants(item).keySet());
        if (item != null && item.hasItemMeta()) {
            for (Enchantment enchantment : item.getEnchantments().keySet()) {
                ids.add(enchantment.getKey().toString());
            }
            if (item.getItemMeta() instanceof EnchantmentStorageMeta storageMeta) {
                for (Enchantment enchantment : storageMeta.getStoredEnchants().keySet()) {
                    ids.add(enchantment.getKey().toString());
                }
            }
        }
        return ids;
    }
}
