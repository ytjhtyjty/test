package ru.multienchant.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import ru.multienchant.enchant.CustomEnchant;
import ru.multienchant.enchant.EnchantIds;
import ru.multienchant.enchant.EnchantRegistry;
import ru.multienchant.enchant.EnchantTarget;
import ru.multienchant.locale.Messages;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Загрузка и валидация всех YAML-файлов в неизменяемый снапшот + типизированные
 * представления механик (DrillView, LumberjackView, ...), читающие параметры
 * из enchants.yml через реестр чар.
 *
 * При reload() новый снапшот собирается целиком; в случае ошибки продолжает
 * действовать предыдущий (атомарная подмена volatile-поля).
 */
public final class ConfigManager {

    public static final class ConfigException extends Exception {
        public ConfigException(String message) {
            super(message);
        }

        public ConfigException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /** Результат reload: при неуспехе error содержит причину, старый снапшот сохраняется. */
    public record ReloadResult(boolean success, String error) {
        public static ReloadResult ok() {
            return new ReloadResult(true, null);
        }

        public static ReloadResult fail(String error) {
            return new ReloadResult(false, error);
        }
    }

    public record LampConfig(int updatePeriodTicks, int effectDurationSeconds) {
    }

    public record TableConfig(boolean enabled, Map<Integer, Double> chanceBySlot,
                              Map<Integer, Double> levelWeights) {
    }

    public record FishingConfig(boolean enabled, double baseChance, boolean requireOpenWater,
                                double luckBonusPerLevel, Map<Integer, Double> levelWeights) {
    }

    public record VillagerConfig(boolean enabled, double chance, int emeraldMin, int emeraldMax,
                                 int maxUses, boolean restock, Map<Integer, Double> levelWeights) {
    }

    public record LootConfig(boolean enabled, double chance, Map<Integer, Double> levelWeights,
                             List<String> tables, Set<String> enchants) {
    }

    public record AnvilConfig(int tooExpensiveThreshold) {
        /** Верхний предел отображаемой стоимости (порог "Слишком дорого"). */
        public int maxCost() {
            return tooExpensiveThreshold;
        }
    }

    public record EffectConfig(String sound, boolean particles) {
    }

    public record IntegrationsConfig(boolean worldguard, boolean placeholderapi) {
    }

    public record Snapshot(EnchantRegistry registry,
                           Messages messages,
                           LampConfig lamp,
                           TableConfig table,
                           FishingConfig fishing,
                           VillagerConfig villagers,
                           LootConfig loot,
                           AnvilConfig anvil,
                           boolean effectsEnabled,
                           Map<String, EffectConfig> effects,
                           IntegrationsConfig integrations,
                           boolean allowConflictBypass,
                           boolean debug,
                           ru.multienchant.filter.FilterCatalogs filterCatalogs) {
    }

    private final JavaPlugin plugin;
    private volatile Snapshot snapshot;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /** Перезагрузка всех YAML. Атомарно: при ошибке действует прежний снапшот. */
    public ReloadResult reload() {
        try {
            this.snapshot = load(plugin);
            return ReloadResult.ok();
        } catch (ConfigException e) {
            return ReloadResult.fail(e.getMessage());
        }
    }

    public Snapshot snapshot() {
        return snapshot;
    }

    public EnchantRegistry registry() {
        return snapshot.registry();
    }

    public Messages messages() {
        return snapshot.messages();
    }

    public TableConfig table() {
        return snapshot.table();
    }

    public FishingConfig fishing() {
        return snapshot.fishing();
    }

    public VillagerConfig villagers() {
        return snapshot.villagers();
    }

    public LootConfig loot() {
        return snapshot.loot();
    }

    public AnvilConfig anvil() {
        return snapshot.anvil();
    }

    public boolean allowConflictBypass() {
        return snapshot.allowConflictBypass();
    }

    public boolean debug() {
        return snapshot.debug();
    }

    // ------------------------------------------------------------------
    // Представления механик: параметры из enchants.yml (через реестр чар)
    // ------------------------------------------------------------------

    private Optional<CustomEnchant> enchant(String id) {
        return snapshot.registry().byId(id);
    }

    /** Общая база: механика включена, если чара зарегистрирована и enabled != false. */
    private boolean mechanicEnabled(String id) {
        return enchant(id).map(e -> e.boolParam("enabled", true)).orElse(false);
    }

    public DrillView drill() {
        return new DrillView(enchant(EnchantIds.DRILL).orElse(null));
    }

    public LumberjackView lumberjack() {
        return new LumberjackView(enchant(EnchantIds.LUMBERJACK).orElse(null));
    }

    public MagnetView magnet() {
        return new MagnetView(mechanicEnabled(EnchantIds.MAGNET));
    }

    public AutoSmeltView autoSmelt() {
        return new AutoSmeltView(enchant(EnchantIds.AUTO_SMELT).orElse(null));
    }

    public ExperienceView experience() {
        return new ExperienceView(enchant(EnchantIds.EXPERIENCE).orElse(null));
    }

    public LavaWalkerView lavaWalker() {
        return new LavaWalkerView(enchant(EnchantIds.LAVA_WALKER).orElse(null));
    }

    public LampView lamp() {
        return new LampView(mechanicEnabled(EnchantIds.LAMP), snapshot.lamp());
    }

    public FilterView filter() {
        return new FilterView(enchant(EnchantIds.FILTER).orElse(null));
    }

    public ru.multienchant.filter.FilterCatalogs filterCatalogs() {
        return snapshot.filterCatalogs();
    }

    /** Единый фасад настроек получения чар (стол/рыбалка/жители). */
    public AcquisitionView acquisition() {
        return new AcquisitionView(snapshot.table(), snapshot.fishing(), snapshot.villagers());
    }

    public record AcquisitionView(TableConfig table, FishingConfig fishing, VillagerConfig villagers) {
        public boolean tableEnabled() {
            return table.enabled();
        }

        /** Шанс по кнопке стола: whichButton() = 0/1/2 -> слот 1/2/3 в конфиге. */
        public double tableSlotChance(int button) {
            return table.chanceBySlot().getOrDefault(button + 1, 0.0);
        }

        public Map<Integer, Double> tableLevelWeights() {
            return table.levelWeights();
        }

        public boolean fishingEnabled() {
            return fishing.enabled();
        }

        public double fishingChance() {
            return fishing.baseChance();
        }

        public boolean fishingRequireOpenWater() {
            return fishing.requireOpenWater();
        }

        public double fishingLuckMultiplier() {
            return fishing.luckBonusPerLevel();
        }

        public Map<Integer, Double> fishingLevelWeights() {
            return fishing.levelWeights();
        }

        public boolean villagerEnabled() {
            return villagers.enabled();
        }

        public double villagerChance() {
            return villagers.chance();
        }

        public int villagerPriceMin() {
            return villagers.emeraldMin();
        }

        public int villagerPriceMax() {
            return villagers.emeraldMax();
        }

        public int villagerMaxUses() {
            return villagers.maxUses();
        }

        public Map<Integer, Double> villagerLevelWeights() {
            return villagers.levelWeights();
        }
    }

    public record DrillView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        public boolean creativeEnabled() {
            return enchant != null && enchant.boolParam("creative-enabled", false);
        }

        public boolean sneakDisables() {
            return enchant == null || enchant.boolParam("sneak-disables", true);
        }

        public boolean sameTypeOnly() {
            return enchant != null && enchant.boolParam("same-type-only", false);
        }

        public double chance(int level) {
            return enchant == null ? 0.0 : enchant.chanceForLevel(enchant.clampLevel(level));
        }
    }

    public record LumberjackView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        public boolean creativeEnabled() {
            return enchant != null && enchant.boolParam("creative-enabled", false);
        }

        public boolean sneakDisables() {
            return enchant == null || enchant.boolParam("sneak-disables", true);
        }

        public int maxBlocks() {
            return enchant == null ? 128 : enchant.intParam("block-limit", 128);
        }

        public boolean includeLeaves() {
            return enchant != null && enchant.boolParam("break-leaves", false);
        }

        public int maxLeaves() {
            return enchant == null ? 256 : enchant.intParam("leaves-limit", 256);
        }

        public double chance(int level) {
            return enchant == null ? 0.0 : enchant.chanceForLevel(enchant.clampLevel(level));
        }
    }

    public record MagnetView(boolean enabled) {
    }

    public record AutoSmeltView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        /** true — Шёлк главнее: дроп не плавится (silk-priority, по умолчанию). */
        public boolean silkPriority() {
            return enchant == null
                    || "silk-priority".equalsIgnoreCase(enchant.stringParam("silk-touch-mode", "silk-priority"));
        }

        /** true — выдавать опыт печи за переплавленные предметы. */
        public boolean furnaceXp() {
            return enchant != null && enchant.boolParam("furnace-xp", false);
        }
    }

    public record ExperienceView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        /** Бонус к опыту с мобов, %. */
        public double mobBonusPercent(int level) {
            return enchant == null ? 0.0 : enchant.bonusForLevel(enchant.clampLevel(level));
        }

        /** Бонус к опыту с руд, % (та же шкала, что и для мобов). */
        public double oreBonusPercent(int level) {
            return mobBonusPercent(level);
        }
    }

    public record LavaWalkerView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        public int radius(int level) {
            return enchant == null ? 0 : enchant.radiusForLevel(enchant.clampLevel(level));
        }

        public boolean convertFlowing() {
            return enchant != null && enchant.boolParam("convert-flowing", false);
        }

        public int maxPerTrigger() {
            return enchant == null ? 30 : enchant.intParam("per-trigger-limit", 30);
        }

        public int maxPerSecond() {
            return enchant == null ? 60 : enchant.intParam("per-second-limit", 60);
        }
    }

    public record FilterView(CustomEnchant enchant) {
        public boolean enabled() {
            return enchant != null && enchant.boolParam("enabled", true);
        }

        /** true — Фильтр применяется ПОСЛЕ Автоплавки (по умолчанию). */
        public boolean autoSmeltBeforeFilter() {
            return enchant == null
                    || enchant.boolParam("processing-order.auto-smelt-before-filter", true);
        }

        /** Требовать подтверждение при отключении ценного материала. */
        public boolean valuableConfirmation() {
            return enchant == null || enchant.boolParam("gui.valuable-confirmation", true);
        }

        public String guiTitle() {
            return enchant == null ? "Фильтр добычи" : enchant.stringParam("gui.title", "Фильтр добычи");
        }

        public boolean enableAllButton() {
            return enchant == null || enchant.boolParam("gui.enable-all-button", true);
        }

        public boolean disableAllButton() {
            return enchant == null || enchant.boolParam("gui.disable-all-button", true);
        }

        /** Максимум отключённых материалов (-1 — без ограничения). */
        public int maxDisabledMaterials() {
            return enchant == null ? -1 : enchant.intParam("limits.max-disabled-materials", -1);
        }
    }

    public record LampView(boolean enabled, LampConfig config) {
        public int updatePeriodTicks() {
            return config.updatePeriodTicks();
        }

        public int effectDurationTicks() {
            return config.effectDurationSeconds() * 20;
        }
    }

    // ------------------------------------------------------------------
    // Статическая загрузка снапшота
    // ------------------------------------------------------------------

    /** Сохраняет дефолтные ресурсы (если отсутствуют) и загружает снапшот. */
    public static Snapshot load(JavaPlugin plugin) throws ConfigException {
        for (String name : new String[]{"config.yml", "enchants.yml", "loot.yml", "messages.yml", "integrations.yml", "filter-catalogs.yml"}) {
            if (!new File(plugin.getDataFolder(), name).exists()) {
                plugin.saveResource(name, false);
            }
        }
        YamlConfiguration config = loadYaml(new File(plugin.getDataFolder(), "config.yml"));
        YamlConfiguration enchants = loadYaml(new File(plugin.getDataFolder(), "enchants.yml"));
        YamlConfiguration loot = loadYaml(new File(plugin.getDataFolder(), "loot.yml"));
        YamlConfiguration messages = loadYaml(new File(plugin.getDataFolder(), "messages.yml"));
        YamlConfiguration integrations = loadYaml(new File(plugin.getDataFolder(), "integrations.yml"));

        EnchantRegistry registry = parseEnchants(enchants);
        Messages msg = new Messages(messages);

        LampConfig lamp = new LampConfig(
                positive(config.getInt("lamp.update-period-ticks", 100), "lamp.update-period-ticks"),
                positive(config.getInt("lamp.effect-duration-seconds", 15), "lamp.effect-duration-seconds"));

        TableConfig table = new TableConfig(
                config.getBoolean("enchant-table.enabled", true),
                intDoubleMap(config.getConfigurationSection("enchant-table.chance-by-slot")),
                levelWeights(config.getConfigurationSection("enchant-table.level-weights")));

        FishingConfig fishing = new FishingConfig(
                config.getBoolean("fishing.enabled", true),
                config.getDouble("fishing.base-chance", 0.8),
                config.getBoolean("fishing.require-open-water", true),
                config.getDouble("fishing.luck-of-the-sea-bonus-per-level", 0.2),
                levelWeights(config.getConfigurationSection("fishing.level-weights")));

        int emeraldMin = config.getInt("villagers.emerald-min", 40);
        int emeraldMax = config.getInt("villagers.emerald-max", 64);
        if (emeraldMin < 1 || emeraldMax < emeraldMin || emeraldMax > 64) {
            throw new ConfigException("villagers.emerald-min/max: некорректный диапазон (" + emeraldMin + ".." + emeraldMax + ")");
        }
        VillagerConfig villagers = new VillagerConfig(
                config.getBoolean("villagers.enabled", true),
                config.getDouble("villagers.chance", 10.0),
                emeraldMin, emeraldMax,
                positive(config.getInt("villagers.max-uses", 3), "villagers.max-uses"),
                config.getBoolean("villagers.restock", false),
                levelWeights(config.getConfigurationSection("villagers.level-weights")));

        Set<String> lootEnchants = new LinkedHashSet<>(loot.getStringList("loot.enchants"));
        for (String id : lootEnchants) {
            if (!registry.contains(id)) {
                throw new ConfigException("loot.enchants: неизвестный id чары '" + id + "'");
            }
        }
        LootConfig lootConfig = new LootConfig(
                loot.getBoolean("loot.enabled", true),
                loot.getDouble("loot.chance", 3.0),
                levelWeights(loot.getConfigurationSection("loot.level-weights")),
                new ArrayList<>(loot.getStringList("loot.tables")),
                lootEnchants);

        AnvilConfig anvil = new AnvilConfig(
                positive(config.getInt("anvil.too-expensive-threshold", 40), "anvil.too-expensive-threshold"));

        Map<String, EffectConfig> effects = new LinkedHashMap<>();
        ConfigurationSection effectsSection = config.getConfigurationSection("effects");
        boolean effectsEnabled = effectsSection == null || effectsSection.getBoolean("enabled", true);
        if (effectsSection != null) {
            for (String key : effectsSection.getKeys(false)) {
                ConfigurationSection sub = effectsSection.getConfigurationSection(key);
                if (sub != null) {
                    effects.put(key, new EffectConfig(
                            sub.getString("sound", ""),
                            sub.getBoolean("particles", false)));
                }
            }
        }

        IntegrationsConfig integrationsConfig = new IntegrationsConfig(
                integrations.getBoolean("worldguard.enabled", true),
                integrations.getBoolean("placeholderapi.enabled", true));

        YamlConfiguration filterCatalogsYaml =
                loadYaml(new File(plugin.getDataFolder(), "filter-catalogs.yml"));
        ru.multienchant.filter.FilterCatalogs filterCatalogs =
                ru.multienchant.filter.FilterCatalogs.parse(filterCatalogsYaml, plugin.getLogger());

        return new Snapshot(registry, msg, lamp, table, fishing, villagers, lootConfig, anvil,
                effectsEnabled, effects, integrationsConfig,
                config.getBoolean("allow-conflict-bypass", false),
                config.getBoolean("debug", false),
                filterCatalogs);
    }

    private static YamlConfiguration loadYaml(File file) throws ConfigException {
        try {
            YamlConfiguration yaml = new YamlConfiguration();
            yaml.load(file);
            return yaml;
        } catch (Exception e) {
            throw new ConfigException("Не удалось прочитать " + file.getName() + ": " + e.getMessage(), e);
        }
    }

    /** Рекурсивная развёртка скалярных параметров чары (вложенные секции -> dotted-ключи). */
    private static void flattenParams(ConfigurationSection section, String prefix,
                                      CustomEnchant.Builder builder) {
        for (String key : section.getKeys(false)) {
            String path = prefix.isEmpty() ? key : prefix + "." + key;
            Object value = section.get(key);
            if (value instanceof Boolean b) {
                builder.boolParam(path, b);
            } else if (value instanceof Integer i) {
                builder.intParam(path, i);
            } else if (value instanceof String s) {
                builder.stringParam(path, s);
            } else if (value instanceof ConfigurationSection sub) {
                flattenParams(sub, path, builder);
            }
        }
    }

    private static EnchantRegistry parseEnchants(YamlConfiguration yaml) throws ConfigException {
        ConfigurationSection section = yaml.getConfigurationSection("enchants");
        if (section == null) {
            throw new ConfigException("enchants.yml: отсутствует секция 'enchants'");
        }
        List<CustomEnchant> list = new ArrayList<>();
        for (String id : section.getKeys(false)) {
            ConfigurationSection e = section.getConfigurationSection(id);
            if (e == null) {
                throw new ConfigException("enchants.yml: секция '" + id + "' пуста");
            }
            try {
                CustomEnchant.Builder builder = CustomEnchant.builder(id)
                        .maxLevel(e.getInt("max-level", 1))
                        .anvilWeight(e.getInt("anvil-weight", 2));
                for (String target : e.getStringList("targets")) {
                    try {
                        builder.target(EnchantTarget.valueOf(target.toUpperCase()));
                    } catch (IllegalArgumentException ex) {
                        throw new ConfigException("enchants.yml: у '" + id + "' неизвестная цель '" + target + "'");
                    }
                }
                for (String conflict : e.getStringList("conflicts")) {
                    builder.conflict(conflict);
                }
                readLevelDoubles(e.getConfigurationSection("chance-per-level"), builder::chance);
                readLevelDoubles(e.getConfigurationSection("bonus-per-level"), builder::bonus);
                ConfigurationSection radius = e.getConfigurationSection("radius-per-level");
                if (radius != null) {
                    for (String key : radius.getKeys(false)) {
                        builder.radius(Integer.parseInt(key), radius.getInt(key));
                    }
                }
                // Прочие скалярные параметры чары — как типизированные params;
                // вложенные секции разворачиваются в dotted-ключи ("gui.rows" и т.п.)
                flattenParams(e, "", builder);
                list.add(builder.build());
            } catch (IllegalArgumentException ex) {
                throw new ConfigException("enchants.yml: " + ex.getMessage());
            }
        }
        if (list.isEmpty()) {
            throw new ConfigException("enchants.yml: не определено ни одной чары");
        }
        return new EnchantRegistry(list);
    }

    private interface LevelDoubleConsumer {
        void accept(int level, double value);
    }

    private static void readLevelDoubles(ConfigurationSection section, LevelDoubleConsumer consumer)
            throws ConfigException {
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                consumer.accept(Integer.parseInt(key), section.getDouble(key));
            } catch (NumberFormatException ex) {
                throw new ConfigException("Некорректный ключ уровня '" + key + "' в " + section.getCurrentPath());
            }
        }
    }

    private static Map<Integer, Double> levelWeights(ConfigurationSection section) throws ConfigException {
        Map<Integer, Double> map = intDoubleMap(section);
        if (map.isEmpty()) {
            map.put(1, 100.0);
        }
        for (Map.Entry<Integer, Double> entry : map.entrySet()) {
            if (entry.getValue() < 0) {
                throw new ConfigException("Отрицательный вес уровня " + entry.getKey()
                        + " в " + (section != null ? section.getCurrentPath() : "?"));
            }
        }
        return map;
    }

    private static Map<Integer, Double> intDoubleMap(ConfigurationSection section) throws ConfigException {
        Map<Integer, Double> map = new LinkedHashMap<>();
        if (section == null) {
            return map;
        }
        for (String key : section.getKeys(false)) {
            try {
                map.put(Integer.parseInt(key), section.getDouble(key));
            } catch (NumberFormatException ex) {
                throw new ConfigException("Некорректный числовой ключ '" + key + "' в " + section.getCurrentPath());
            }
        }
        return map;
    }

    private static int positive(int value, String path) throws ConfigException {
        if (value <= 0) {
            throw new ConfigException(path + ": значение должно быть положительным (" + value + ")");
        }
        return value;
    }
}
